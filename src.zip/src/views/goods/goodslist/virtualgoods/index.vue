<template>
  <div class="container">
    虚拟商品
  </div>
</template>

<script>
export default {
    name: 'virtualgoods'
}
</script>

<style>

</style>