<template>
  <div class="container">
    <div class="Search">
      <div class="Search-condition">
        <div class="query-input">
          <el-input
            size="medium"
            v-model="inputInfo.name"
            @keyup.enter.native="demand"
            :placeholder="$t('tagList.qsrspbq')"
          ></el-input>
        </div>
        <div class="btn-list">
          <el-button @click="reset" plain>{{$t('DemoPage.tableExamplePage.reset')}}</el-button>
          <el-button class="bgColor" type="primary" @click="demand"
            >{{ $t("DemoPage.tableExamplePage.demand") }}
          </el-button>
        </div>
      </div>
    </div>
    <div class="jump-list">
      <el-button
        v-if="detectionBtn(button_list, '添加商品标签')"
        class="bgColor laiketui laiketui-add"
        type="primary"
        @click="dialogShow"
        >{{$t('tagList.xzbq')}}
      </el-button>
    </div>

    <!-- 弹框组件 -->
    <div class="dialog-block">
      <el-dialog
        :title="title"
        :visible.sync="dialogVisible"
        :before-close="handleClose"
      >
        <el-form
          :model="dataForm"
          :rules="rules"
          ref="ruleForm2"
          label-width="auto"
          class="demo-ruleForm"
        >
          <div class="">
            <el-form-item :label="$t('tagList.bqmc')" prop="name">
              <el-input type="text" maxlength="4" v-model="dataForm.name"></el-input>
            </el-form-item>
            <el-form-item :label="$t('tagList.qxzbjs')" required style="margin-bottom:0">
              <el-color-picker v-model="dataForm.color" popper-class="color-popper"></el-color-picker>
              <!-- <el-select v-model="dataForm.color" >
                <el-option
                  v-for="item in colorlist"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                  <div style="display: flex;justify-content: space-between;">
                    <div class="mytag mytag1" :style="{background:item.label}"></div>
                    <span v-show="item.value==dataForm.color">✔</span>
                  </div>
                  
                </el-option>
              </el-select> -->
            </el-form-item>
          </div>
          <div class="form-footer">
            <el-form-item>
              <el-button class="fontColor" @click="handleClose()"
                >{{$t('tagList.ccel')}}</el-button
              >
              <el-button
                type="primary"
                @click="Save('ruleForm2')"
                class="qdcolor"
                >{{$t('tagList.okk')}}</el-button
              >
            </el-form-item>
          </div>
        </el-form>
      </el-dialog>
    </div>

    <div class="merchants-list" ref="tableFather">
      <el-table
        :element-loading-text="$t('DemoPage.tableExamplePage.loading_text')"
        v-loading="loading"
        :data="tableData"
        ref="table"
        class="el-table"
        style="width: 100%"
        :height="tableHeight"
      >
      <template slot="empty">
          <div class="empty"> 
            <img src="../../../assets/imgs/empty.png" alt="" />
            <p style="color: #414658">{{ $t('zdata.zwsj') }}</p>
          </div>
        </template>
        <el-table-column prop="id" :label="$t('tagList.bqid')" width="100"> </el-table-column>
        <el-table-column prop="" :label="$t('tagList.bq')">
          <template slot-scope="scope">
            <div style="display:flex;justify-content: center;">
              <div class="mytag" :style="{ background: scope.row.color }">
                {{ scope.row.name }}
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="name" :label="$t('tagList.bqmc')"> </el-table-column>
        <el-table-column :label="$t('tagList.tjsj')">
          <template slot-scope="scope">
            {{ scope.row.add_time | dateFormat }}
          </template>
        </el-table-column>
        <el-table-column fixed="right" :label="$t('tagList.cz')" width="200">
          <template slot-scope="scope">
            <div class="OP-button">
              <div class="OP-button-top">
                <el-button
                  v-if="detectionBtn(button_list, '编辑商品标签') && scope.row.name != '推荐' && scope.row.name != '热销' && scope.row.name != '新品'"
                  icon="el-icon-edit-outline"
                  @click="Show(scope.row.id)"
                  >{{$t('tagList.bianji')}}</el-button
                >
                <el-button
                  v-if="detectionBtn(button_list, '删除商品标签') && scope.row.name != '推荐' && scope.row.name != '热销' && scope.row.name != '新品'"
                  icon="el-icon-delete"
                  @click="Delete(scope.row.id)"
                  >{{$t('tagList.shanchu')}}</el-button
                >
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <div class="pageBox" ref="pageBox">
        <div class="pageLeftText">{{$t('DemoPage.tableExamplePage.show')}}</div>
        <el-pagination
          layout="sizes, slot, prev, pager, next"
          :prev-text="$t('DemoPage.tableExamplePage.prev_text')"
          :next-text="$t('DemoPage.tableExamplePage.next_text')"
          @size-change="handleSizeChange"
          :page-sizes="pagesizes"
          :current-page="pagination.page"
          @current-change="handleCurrentChange"
          :total="total"
        >
          <div class="pageRightText">{{$t('DemoPage.tableExamplePage.on_show')}}{{currpage}}-{{current_num}}{{$t('DemoPage.tableExamplePage.twig')}}{{total}}{{ $t('DemoPage.tableExamplePage.twig_notes') }}</div>
        </el-pagination>
      </div>
    </div>
  </div>
</template>


<script>
import tagList from "@/webManage/js/goods/tag/tagList";
// import { backgroundClip } from "html2canvas/dist/types/css/property-descriptors/background-clip";
export default tagList;
</script>
<style>
.color-popper{
  left: 832px !important;
}
</style>
<style scoped lang="less">
.mytag{
  padding: 0 5px;
  height: 22px;
  border-radius: 4px;
  color: #fff;
}
.mytag1{
  width: 32px;
  margin: 8px 0;
}
/deep/.myselect .el-input{
  width: 360px!important;
}

/deep/.el-dialog__header{
  border-bottom:1px solid #E9ECEF!important;
}
/deep/.el-button--default{
  background: #fff
}
@import "../../../common/commonStyle/form";
@import "../../../webManage/css/goods/tag/tagList.less";
</style>
