<template>
  <div class="container">
    <!-- <div class="header">
      <span>添加用户</span>
    </div> -->

    <el-form :model="ruleForm" label-position="right" :rules="rule" ref="ruleForm" label-width="80px" class="form-search">
      <div class="notice">
        <el-form-item :label="$t('addMembers.yhtx')" id="upload" prop="membersHead" ref="membersHead">
						<l-upload
              :limit="1"
              v-model="ruleForm.membersHead"
              text=" "
            >
            </l-upload>
				</el-form-item>
        <el-form-item :label="$t('addMembers.yhmc')" prop="userName">
          <el-input v-model="ruleForm.userName" :placeholder="$t('addMembers.qsryhmc')"></el-input>
          <!-- <span class="gray">(用户名称默认显示用户设置的昵称)</span> -->
        </el-form-item>
        <el-form-item label="用户角色">
          <el-select
            class="select-input"
            v-model="ruleForm.roleId"
          >
            <el-option
              v-for="(item, index) in roleList"
              :key="index"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        
        <!-- <el-form-item :label="用户级别" prop="grade">
          <el-select class="select-input" v-model="ruleForm.grade" placeholder="请选择用户等级">
            <el-option v-for="(item,index) in membersGrade" :key="index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <span class="gray">(用户级别默认显示普通用户)</span>
        </el-form-item> -->
        <el-form-item :label="$t('addMembers.yhzh')" prop="zhanghao">
          <el-input 
          maxlength="16"
          v-on:input="ruleForm.zhanghao=ruleForm.zhanghao.replace(/[^\w]/g,'')"
          v-model="ruleForm.zhanghao" :placeholder="$t('addMembers.qsryhzh')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('addMembers.yhmm')" prop="mima">
          <el-input 
          v-on:input="ruleForm.mima=ruleForm.mima.replace(/[^\w]/g,'')"
          v-model="ruleForm.mima" :placeholder="$t('addMembers.qsryhmm')" show-password auto-complete="new-password"></el-input>
        </el-form-item>
        <el-form-item :label="$t('addMembers.qrmm')" prop="confirmMima">
          <el-input 
          v-on:input="ruleForm.confirmMima=ruleForm.confirmMima.replace(/[^\w]/g,'')"
          v-model="ruleForm.confirmMima" :placeholder="$t('addMembers.qqrmm')" show-password auto-complete="new-password"></el-input>
        </el-form-item>
        <el-form-item :label="$t('addMembers.sjhm')" prop="phone">
          <el-input  
          v-on:input="ruleForm.phone=ruleForm.phone.replace(/^(-1+)|[^\d]+/g,'')"
          v-model="ruleForm.phone" 
          :placeholder="$t('addMembers.qsrsjhm')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('addMembers.zhly')" prop="source">
          <el-select class="select-input" v-model="ruleForm.source" :placeholder="$t('addMembers.qxzzhly')">
            <el-option v-for="(item,index) in sourceList" :key="index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
       
        <el-form-item :label="$t('editorMembers.xb')">
          <el-select
            class="select-input"
            v-model="ruleForm.sex"
          >
            <el-option
              v-for="(item, index) in sexList"
              :key="index"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
      
        <el-form-item class="footer-button">
        <!-- <div class="footer-button"> -->
          <el-button type="primary" class="footer-save bgColor mgleft" @click="submitForm('ruleForm')">{{ $t('DemoPage.tableFromPage.save') }}</el-button>
          <el-button plain class="footer-cancel fontColor kid_left" @click="$router.go(-1)">{{ $t('DemoPage.tableFromPage.cancel') }}</el-button>
        <!-- </div> -->
        </el-form-item>
      </div>
		</el-form>
  </div>
</template>

<script>
import addMembers from '@/webManage/js/members/membersList/addMembers'
export default addMembers
</script>

<style scoped lang="less">
@import '../../../../webManage/css/members/membersList/addMembers.less';
</style>