<template>
    <div class="order_detail_page">
        <div class="big_title">基本信息</div>

        <ul class="info_list_con">
           
            <li>
                <div class="item">
                    <div class="tit">订单类型</div>
                    <div class="txt" @click="getOrderInfoFn">----</div>
                </div>
                <div class="item">
                    <div class="tit">母订单号</div>
                    <div class="txt">--------</div>
                </div>
                <div class="item">
                    <div class="tit">子订单号</div>
                    <div class="txt">--------</div>
                </div>
                <div class="item">
                    <div class="tit">订单状态</div>

                    <div class="txt">----</div>
                </div>
                <div class="item">

                    <div class="tit">订单来源</div>

                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">渠道</div>

                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">工厂</div>


                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">品牌</div>

                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">订单跟踪备注</div>
                    <div class="txt">
                        <el-input
                            type="textarea"
                            :autosize="{maxRows: 5}"
                            placeholder="请输入内容"
                            v-model="textarea2">
                            </el-input>
                    </div>
                </div>
            </li>
            <li>
                <div class="item">
                    <div class="tit">下单时间</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">期望发货时间</div>
                    <div class="txt">
                        <p>----</p>
                        <el-button @click="changeTimedialogVisible=true" size="mini" style="margin-top:10px;">  修改</el-button>
                    </div>
                </div>
                <div class="item">
                    <div class="tit">工厂预计发货时间</div>
                    <div class="txt">----</div>   
                </div>


                <div class="item">
                    <div class="tit">指定工厂发货时间</div>
                    <div class="txt">----</div>   
                </div>
                <div class="item">
                    <div class="tit">工厂实际发货时间</div>
                    <div class="txt">----</div>   
                </div>
                <div class="item">


                    <div class="tit">平台实际发货时间</div>
                    <div class="txt">----</div>   
                </div>
                <div class="item">
                    <div class="tit">子单税费</div>
                    <div class="txt">----</div>
                </div>
                

                <div class="item">
                    <div class="tit">客户备注</div>
                    <div class="txt">----</div>
                </div>
            </li>
            <li>
                <div class="item">
                    <div class="tit">工厂发货类型</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">物流单号</div>
                    <div class="txt"> ---- </div>
                </div>
                <div class="item">
                    <div class="tit">收货人信息</div>
                    
                    <div class="txt">   
                        <p>----</p>
                        <el-button @click="changeUserInfodialogVisible=true" size="mini" style="margin-top:10px;">  修改</el-button>
                     </div>
                   



                </div>
                <div class="item">

                    <div class="tit">采购总金额</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">工厂备注</div>
                    <div class="txt">----</div>
                </div>
            </li>


            <li>
                <div class="item">
                    <div class="tit">发票类型</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">发票抬头</div>
                    <div class="txt"> ---- </div>
                </div>
                <div class="item">
                    <div class="tit">发票内容类别</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">纳税人识别码</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">单位地址</div>
                    <div class="txt">----</div>
                </div>
                

                <div class="item">
                    <div class="tit">单位电话</div>
                    <div class="txt">----</div>
                </div>

                <div class="item">
                    <div class="tit">开户银行</div>
                    <div class="txt">----</div>
                </div>
                <div class="item">
                    <div class="tit">银行帐号</div>
                    <div class="txt">----</div>
                </div>
            </li>
        </ul>

        <div class="big_title">商品信息</div>
         

        <el-table   :data="goodArr"   style="width: 100%"          
            :header-cell-style="{textAlign:'center'}"
            :cell-style="{textAlign:'center'}"
            class="order_good_table">
            <el-table-column prop="name" label="商品信息" width="350">
                <template slot-scope="scope">
                    ----
                    <!-- <img :src= "scope.row.img " alt="" class="good_img"/> -->
                </template>
            </el-table-column>
            <el-table-column prop="subtitle" label="采购价" width="100">
                 
                -----
            </el-table-column>
            <el-table-column prop="address" label="购买数量" width="200" >
               -----
            </el-table-column>
            <el-table-column prop="address" label="包件数" width="100">
               ----
            </el-table-column>
            <el-table-column prop="address" label="采购合计"  width="200">
            
                ----
            </el-table-column>
            <el-table-column prop="subtitle" label="是否质检" width="200">
                 -----
             </el-table-column>

            <el-table-column prop="address" label="状态">
                <template slot-scope="scope">
                    <div>----</div>
                </template>
            </el-table-column>
           
           
        </el-table>
        

        <div class="big_title">订单处理流程</div>

        <div class="record_con">
            <el-timeline>
                <el-timeline-item timestamp="2018/4/12" placement="top">
                <el-card>
                    <h4>提交</h4>
                    <p>王小虎 提交于 2018/4/12 20:46</p>
                    
                    <el-table :data="orderTimeGoodTable" style="width: 29%;margin-top:10px;" :border="true">
                        <el-table-column
                            prop="goodName"
                            label="商品"
                            width="250">
                        </el-table-column>
                        <el-table-column
                            prop="count"
                            label="数量">
                        </el-table-column>
                    </el-table>
                </el-card>
                </el-timeline-item>
                <el-timeline-item timestamp="2018/4/3" placement="top">
                <el-card>
                    <h4>提交</h4>
                    <p>王小虎 提交于 2018/4/3 20:46</p>
                </el-card>
                </el-timeline-item>
                <el-timeline-item timestamp="2018/4/2" placement="top">
                <el-card>
                    <h4>提交</h4>
                    <p>王小虎 提交于 2018/4/2 20:46</p>
                </el-card>
                </el-timeline-item>
            </el-timeline>
        </div>


      
        <el-dialog
            title="期望发货时间"
            :visible.sync="changeTimedialogVisible"

            width="31%"
            :center="true"
            :before-close="handleCloseChangeTimeFn">
            
            <div class="order_info_item">
                <div class="title">期望时间:</div>
                <el-date-picker v-model="dateStr" type="datetime" placeholder="选择日期" class="text" @change="selectDateFn"></el-date-picker>
            </div>
            <div class="order_info_item">
                <div class="title">跟单备注:</div>
                
                <el-input type="textarea"  :autosize="{ minRows: 5}" placeholder="请输入内容" v-model="remark" class="text"></el-input>
            </div>
            <span slot="footer" class="dialog-footer">
                 
                <el-button @click="changeTimedialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="changeTimedialogVisible = false">确 定</el-button>
            </span>
        </el-dialog>


        <el-dialog
            title="修改收货地址"
            :visible.sync="changeUserInfodialogVisible"

            width="31%"
            :center="true"
            :before-close="handleCloseChangeTimeFn">
            
            <div class="order_info_item">
                <div class="title">所在地区:</div>
                <el-date-picker v-model="dateStr" type="datetime" placeholder="选择日期" class="text" @change="selectDateFn"></el-date-picker>
            </div>
            <div class="order_info_item">
                <div class="title">详细地址:</div>
                
                <el-input type="textarea"  :autosize="{ minRows: 5}" placeholder="请输入内容" v-model="remark" class="text"></el-input>
            </div>
            <div class="order_info_item">
                <div class="title">收货人:</div>
                <el-input type="text"   placeholder="请输入姓名" v-model="remark" class="text"></el-input>
            </div>

            <div class="order_info_item">
                <div class="title">手机号码:</div>
                <el-input type="text"    placeholder="请输入手机号" v-model="remark" class="text"></el-input>
            </div>
            <span slot="footer" class="dialog-footer">
                 
                <el-button @click="changeUserInfodialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="changeUserInfodialogVisible = false">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>


import {  orderDetailsInfo } from '@/api/order/orderList';
export default {
    data () {
        return {
            orderNo: "",
            goodArr: [{}],
            orderTimeGoodTable: [
                {
                    goodName: 'LKS8821-E+F+E-3RW',
                    count: 1
                }, 
                {  
                    goodName: 'LK-X2208-XXY',
                    count: 1
                }

            ],
            multipleSelection: [],
            activities: [
                {
                    content: '活动按期开始',
                    timestamp: '2018-04-15'
                }, 
                {
                    content: '通过审核',
                    timestamp: '2018-04-13'
                }, 
                {
                    content: '创建成功',
                    timestamp: '2018-04-11'
                }
            ],
            orderInfon: "",
            // 期望发货时间
            changeTimedialogVisible: false,
            // 收货人信息弹窗
            changeUserInfodialogVisible: false
        }
    },
    mounted () {  
        this.$nextTick(function () {
            this.init()
        })
    },
    methods: {
        init: function () {
            let orderNo = window.location.href.split("orderNo=")[1];   
            this.orderNo = orderNo;
            this.getOrderInfoFn()
        },
        handleCloseChangeTimeFn: function () {
            this.changeTimedialogVisible = false;
        },
        getOrderInfoFn: function () {
            let _this = this;
            orderDetailsInfo({
                api: "admin.orderV2.purchaseList",
                status: this.status,
                keyWords: this.keyWords,
                orderNo: this.orderNo
            }).then((res)=> {
            
                console.log("--------getOrderInfoFn")
                console.log(res)
                console.log("--------getOrderInfoFn")
                // let resData = res.data.data;   
                // if (resData) {
                //      _this.orderInfon = resData;
                //   _this.goodArr = resData.details;
                // }
            })              
        }    
    }
}
</script>


<style>
@import "./index.css";
</style>
