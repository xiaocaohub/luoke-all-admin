<template>
    <div class="order_list_page">
        <ul class="nav_list_con">

            <li v-for="(navItem, index) in tabNav" :class="{'on': tabIndex==index}" @click="selectNavFn(index)">
                
                {{navItem.title}} <span class="count" v-if="navItem.count">{{  navItem.count }}</span>
            </li>
        </ul>
        
        <el-table :data="orderListArr" style="width: 100%;margin:0 20px;"  @selection-change="handleSelectionChange">
            <el-table-column
            type="selection"
            width="55">
            </el-table-column>
            <el-table-column prop="orderParentNoInfo" label="母单号" width="150">
                <template slot-scope="scope">
                    <div>
                        <p>{{ scope.row.orderParentNoInfo.orderParentNo?scope.row.orderParentNoInfo.orderParentNo:"----" }}</p>
                        <p>(总税费: {{ scope.row.orderParentNoInfo.taxation }}) </p>
                        <p>{{  scope.row.orderParentNoInfo.orderNoCount }}个子单</p>
                    </div>
                </template>
            </el-table-column>
            <el-table-column prop="orderNoInfo" label="子订单号" width="150">
                <template slot-scope="scope">
                    <div>
                        <p>{{ scope.row.orderNoInfo.orderNo?scope.row.orderNoInfo.orderNo:"----" }}</p>
                        <p>(税费: {{ scope.row.orderNoInfo.taxation?scope.row.orderNoInfo.taxation:0 }}) </p>

                    </div>
                </template>
            </el-table-column>
             
            <el-table-column prop="channel" label="结算类型" width="100">

                 


                <template slot-scope="scope">
                    <div>
                        {{ scope.row.settlementType | settlementTypeFn }}
                    </div>
                </template>
            </el-table-column>

            <el-table-column prop="source" label="订单来源" width="100">
                <template slot-scope="scope">
                    <div>
                        {{ scope.row.source | sourceFn}}
                    </div>
                
                </template>
            </el-table-column>  
            <el-table-column prop="channel" label="渠道" width="100">

                <template slot-scope="scope">
                    <div>
                        {{ scope.row.channel?scope.row.channel:"----" }}
                    </div>
                </template>
            </el-table-column>
            <el-table-column prop="brandName" label="品牌" width="80">
                <template slot-scope="scope">
                    <div>


                        {{ scope.row.brandName?scope.row.brandName:"----没有" }}
                    </div>
                </template>


            </el-table-column>
            <el-table-column  prop="factoryName" label="生产工厂" width="200">
                <template slot-scope="scope">

                    <div>
                        {{ scope.row.factoryName?scope.row.factoryName:"----" }}
                    </div>
                </template>
            </el-table-column>

            
            <el-table-column prop="factoryAddress" label=" 服务商/装修公司" width="200">
                <template slot-scope="scope">
                    
                    <div>
                        <p>
                            {{ scope.row.factoryAddress.provice?scope.row.factoryAddress.provice:"----" }} 
                            {{ scope.row.factoryAddress.city?scope.row.factoryAddress.city:"----" }} 
                            {{ scope.row.factoryAddress.area?scope.row.factoryAddress.area:"----" }} 
                            {{ scope.row.factoryAddress.address?scope.row.factoryAddress.address:"----" }}
                        </p>
                        <p> {{ scope.row.factoryAddress.name?scope.row.factoryAddress.name:"----" }} </p>
                        <p>{{ scope.row.factoryAddress.mobile?scope.row.factoryAddress.mobile:"----" }}</p>
                    </div>
                
                </template>
            </el-table-column>
            <el-table-column prop="times" label="时间管理" width="150">
                <template slot-scope="scope">
                    <div>
                       <p>下单时间: {{ scope.row.times.createTime?scope.row.times.createTime:"-----" }}</p>
                       <p>期望发货时间: {{ scope.row.times.expectedTime?scope.row.times.expectedTime:"----" }}</p>
                    </div>
                </template>
            </el-table-column>
            
            <el-table-column prop="deliveryAddress" label="收货信息" width="150">
                <template slot-scope="scope">
                    <div>
                        <p>
                            {{ scope.row.deliveryAddress.provice?scope.row.deliveryAddress.provice:"-----" }}
                            
                            {{ scope.row.deliveryAddress.city?scope.row.deliveryAddress.city:"----" }}

                            {{ scope.row.deliveryAddress.area?scope.row.deliveryAddress.area:"----" }}

                            {{ scope.row.deliveryAddress.address?scope.row.deliveryAddress.address:"----" }}
                        </p>
                        <p>{{  scope.row.deliveryAddress.name?scope.row.deliveryAddress.name:"----" }}</p>
                      
                        <p>{{  scope.row.deliveryAddress.mobile? scope.row.deliveryAddress.mobile:"----" }}</p>
                    </div>
                </template>
            </el-table-column>
            <el-table-column prop="status" label="订单状态" width="100">
                <template slot-scope="scope">
                    <div>{{ scope.row.status | orderStatusFn}}</div>

                </template>
            </el-table-column> 

            <el-table-column  label="操作">
                <template slot-scope="scope">
              
                    <div class="operate_btn_group">
              
              
                        <div class="btn up_btn" @click="showUploadPayFn(scope.row)">上传支付凭证</div>
                        <div class="btn">恢复待付款</div>
                        <router-link :to="'/order/orderList/orderDetails?orderNo=' + scope.row.orderNoInfo.orderNo">订单详情 </router-link>
                        <div class="btn">审核详情</div>

                        <div class="btn">填写发货时间</div>
                        
                        <div class="btn">完成签收</div>
                        <div class="btn">导出采购单</div>
                        <div class="btn">导出工厂单</div>
                    </div>
                </template>
            </el-table-column>
        </el-table>

        <div class="page_con">
 
            <!-- <el-pagination background layout="prev, pager, next" :total="this.total" @current-change="changePageFn"></el-pagination> -->
            <el-pagination background layout="prev, pager, next" :current-page="pageNum" :total="total" @current-change="changePageFn"></el-pagination>
        </div>

        <el-dialog
            title="预计发货时间"
            :visible.sync="orderDialogVisible"
            width="31%"
            
            :center="true"
            :before-close="handleCloseUploadPayFn">
            
            <div class="order_info_item">
                <div class="title">发货时间:</div>
                <el-date-picker v-model="dateStr" type="datetime" placeholder="选择日期" class="text" @change="selectDateFn"></el-date-picker>
            </div>
            <div class="order_info_item">
                <div class="title">跟单备注:</div>
                
                <el-input type="textarea"  :autosize="{ minRows: 5}" placeholder="请输入内容" v-model="remark" class="text"></el-input>
            </div>
          
            <span slot="footer" class="dialog-footer">
                <el-button @click="uploadPayDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirmFn">确 定</el-button>
            </span>
        </el-dialog>


        
        <el-dialog
            title="上传支付凭证"
            :visible.sync="uploadPayDialogVisible"
            width="50%"
          
            :center="true"
            :before-close="handleClose">
            
            
            <el-form ref="form" :model="uploadPayForm" label-width="80px" class="upload_form"    style="height:500px;overflow:auto;">
                <el-form-item label="订单编号">
                     {{ this.currentOrderItem?this.currentOrderItem.orderNoInfo.orderNo:"----" }}
                </el-form-item>
                <el-form-item label="下单时间">
                     {{ this.currentOrderItem?this.currentOrderItem.times.createTime:"----" }}
                </el-form-item>
                <el-form-item label="订单来源">
                    
                    <p>{{  this.currentOrderItem.source|sourceFn }} </p>
                </el-form-item>
                <el-form-item label="收货地址">
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.provice:"-----" }}        
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.city:"----" }}
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.area:"----" }}

                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.address:"----" }}
                </el-form-item>
                <el-form-item label="订单金额">
                     {{ this.currentOrderItem.totalPrice }} 元
                </el-form-item>

                <el-form-item label="审核留言">
                    <el-input type="textarea" v-model="uploadPayForm.desc"></el-input>

                </el-form-item>

                <div class="line"></div>

                <el-form-item label="收款截图">
                     
                    <el-upload
                        action="https://jsonplaceholder.typicode.com/posts/"
                        list-type="picture-card"
                    >
                        <i class="el-icon-plus"></i>
                    </el-upload>
                </el-form-item>

                <el-form-item label="付款人">
                    <el-input v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
                <el-form-item label="收款银行">
                    
                    <el-input v-model="uploadPayForm.desc"></el-input>
                
                
                </el-form-item>

                <el-form-item label="应收金额">
                    <el-input  v-model="this.currentOrderItem.totalPrice" :disabled="true"></el-input>
                </el-form-item>

                <el-form-item label="线下转账">
                    <el-input v-model="uploadPayForm.desc"></el-input>
                </el-form-item>




                <el-form-item label="收款时间">
                    <el-date-picker  v-model="uploadPayForm.desc" type="date" placeholder="选择日期"></el-date-picker>
                    <p>为了系统和财务统计一致，请认真选择支付时间!</p>
              
                </el-form-item>



        
                <el-form-item label="支付方式">
                    <el-select v-model="uploadPayForm.payType" placeholder="请选择活动区域" @change="selectPayTypeFn">
                        <el-option :label="payTypeItem.title" :value="payTypeItem.value" v-for="(payTypeItem, index) in uploadPayForm.payTypeArr"></el-option>  
                    </el-select>
                </el-form-item>

                <el-form-item label="结款类型">
                    <el-select v-model="uploadPayForm.paymentType" placeholder="请选择活动区域" @change="selectPaymentTypeFn">
                        <el-option :label="payTypeItem.title" :value="payTypeItem.value" v-for="(payTypeItem, index) in uploadPayForm.paymentTypeArr"></el-option>
                       
                    </el-select>
                </el-form-item>

                <el-form-item label="备注">
                    <el-input type="textarea" v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="uploadPayDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirmUploadPayFn">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import {  orderList, confirmOrder } from '@/api/order/orderList';
import { data } from 'jquery';
import orderDetails from '../editorOrder/index.vue';
export default {

    data () {
        return {
            tabNav: [
                {
                    id: 0, 
                    title: "全部订单",
                    status: ""
                },
                {
                    id: 1, 
                    title: "待付款",
                    status: 1,
                    count: 1
                },
                {
                    id: 2, 
                    title: "待审核",
                    status: 2,
                    count: 1
                },
                {
                    id: 3, 
                    title: "待确定--待发货",
                    status: 3,
                    count: 1
                },
                {

                    id: 4, 
                    title: "配货中",
                    status: 4,
                    count: 1
                },
                {
                    id: 5, 
                    title: "已发货",
                    status: 5,

                    count: 1
                },
                {
                    id: 6, 
                    title: "已完成--没有",
                    status: "----",
                    count: 1
                },
                {


                    id: 7, 
                    title: "已取消",
                    status: 0,
                    count: 1
                }
            ],
            tabIndex: 0,
            status: "",
            keyWords: "",
            orderNo: "",
            pageNum: 1,
            pageSize: 10,

            orderListArr: [{}], 
            total: 0,
            orderDialogVisible: false,
            dateStr: "",
            date: "",
            time: "",
            remark: "",

            currentOrder: "",

            multipleSelection: [],
            uploadPayDialogVisible: false, // 支付凭证
            currentOrderItem: "",
            uploadPayForm: {
                payType: "", // 支付方式
                payTypeArr: [
                    {

                        id: 0,

                        title: "银行转账",
                        value: 1
                    }
                ],
                paymentType: "",  // 结款类型
                paymentTypeArr: [
                    {

                        id: 0,
                        
                        title: "现款结清",
                        value: 1
                    },
                    {
                        id: 1,
                        title: "线上转账",
                        value: 2
                    }
                ]
            }         
        }
    },
    mounted () {
         this.$nextTick(function () {
            this.getOrderListFn()
         })
    },

    methods: {
        selectNavFn: function (index) {
            let _this = this;
            if (this.tabIndex != index) {
                this.tabIndex = index;
            }
            this.status = this.tabNav[index].status;
            this.pageNum = 1;
            this.getOrderListFn()
        },
        handleSelectionChange(val) {

            this.multipleSelection = val;
        },
        getOrderListFn: function () {
          
          
            let _this = this;
            orderList({
                api: "admin.orderV2.purchaseList",
                orderParentStatus: this.status,
                pageNum: this.pageNum,
                pageSize: this.pageSize,
            }).then((res)=> {
                let resData = res.data.data;
                
                if (resData) { 
                    let resOrderArr = resData.records;
                    let orderListArr = []; 
                    resOrderArr.forEach((orderItem, index)=> {
                        let item = {}
                        item.orderParentNoInfo = {
                            orderParentNo: orderItem.orderParentNo,
                            taxation: orderItem.opTaxation,
                            orderNoCount: "----"
                        }
                        


                        item.orderNoInfo = {
                            orderNo: orderItem.orderNo,
                            taxation: orderItem.taxation,
                        }
                        item.settlementType = orderItem.settlementType;
                        item.source = orderItem.source;
                        item.channel = orderItem.channel;
                        item.brandName = orderItem.brandName;
                        item.factoryName = orderItem.factoryName; 

                        item.factoryAddress = orderItem.factoryAddress;
                        item.times = {
                            createTime: orderItem.createTime, // 下单时间
                        
                            expectedTime: orderItem.expectedTime
                        }
                        item.deliveryAddress =  orderItem.deliveryAddress;
                        item.status = orderItem.status;

                        // 以下属性, 上传支付凭证
                        item.totalPrice = orderItem.totalPrice; // 订单金额
                        orderListArr.push(item)
                    })
                    _this.orderListArr = orderListArr;
                    _this.total = resData.total;
                }
            })
        },
  
        changePageFn: function (page) {        
            this.pageNum = page;
            this.getOrderListFn()
        },
        confirmOrderFn: function (orderItem) {

            this.currentOrder = orderItem;
            this.orderDialogVisible = true;
        },        
        selectDateFn: function (date) {
            let dateString = new Date(date);
            let year = dateString.getFullYear();
            let Month = dateString.getMonth() + 1;
            let day = dateString.getDate();
            let hours = dateString.getHours();
            let minutes = dateString.getMinutes();
            let seconds = dateString.getSeconds();
         
            this.dateStr = date;
            this.date = year + "年" + Month + "月" + day + "日" ;
            this.time = hours + "时" + minutes + "分" + seconds + "秒";
        },
        handleClose(done) {
            done();
        },

        confirmFn: function () {
        
        
            this.orderDialogVisible = false;
            let _this = this;
            let orderNo = this.currentOrder.orderNoInfo.orderNo;
            confirmOrder({
                api: "mch.App.orderV2.confirm",
                orderNo: orderNo,
                estimatedDeliveryTime: this.dateStr,
                remark: this.remark
            }).then((res)=> {
                //let resData = res.data.data;   
                console.log("confirm order")
                console.log(res)
                console.log("confirm order")
                _this.getOrderListFn()

                if (res.data.code == 200) {
                    _this.$message.success(res.data.message)
                    _this.getOrderListFn()
                } else {
                    _this.$message.error(res.data.message)
                }
                
            })            
        },
        showUploadPayFn: function (orderItem) {
            this.uploadPayDialogVisible = true;
            this.currentOrderItem = orderItem;
            console.log("currentOrderItem")

            console.log(this.currentOrderItem)


            console.log("currentOrderItem")
        },

        handleCloseUploadPayFn: function () {
            this.uploadPayDialogVisible = false;
        },

        confirmUploadPayFn: function () {
            this.uploadPayDialogVisible = false;
        
        },
        selectPayTypeFn: function (value) {
          
            this.uploadPayForm.payType = value;
        
        },
        selectPaymentTypeFn: function (value) {
            this.uploadPayForm.paymentType = value;
        }
    },
    filters: {
         // 结算类型 
         settlementTypeFn: function (status) {
            switch (status) {
                case 1:

                    return "现结";
                    break ;
                default:
                    
                     
                    return "----";
                    break ;
            }
        },
        sourceFn: function (status) {
            switch (status) {
                case 1: 
                   return "珞珂家居PC端";
                   break;
                default:
                   return "----";

                   break;
            }
        },
        orderStatusFn: function (status) {
            switch (status) {

                case 0:
                    return "已取消";
                    break ;

                case 1:
                    return "待付款";
                    break ;

                case 2:
                    return "待确认";
                    break ;
                case 3: 
                    return "待发货";
                
                    break ;
                
                
                
                case 4:
                    return "可发货";    
                    break ;

                case 5:
                    return "已发货";
                    break ;
                default:
                    return "----";
                    break ;
            }
        }
    }
}
</script>


<style>

@import "./index.css";
</style>

