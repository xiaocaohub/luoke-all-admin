<template>
  <div class="container">
    <div class="btn-nav">
      <el-radio-group fill="#2890ff" text-color="#fff" v-model="radio1" ref="tab_bun">
        <el-radio-button label="" v-if="handleTabLimits(routerList,'orderLists',1)">
          {{$t('orderLists.ddlb')}}<span class="order_dfhNum" :class="[ radio1 == '' ? 'active' : '']">({{ this.$store.getters.orderListNum }})</span>
        </el-radio-button>
        <el-radio-button label="1" v-if="handleTabLimits(routerList,'tabPhysicalOrder',1)">
          {{$t('orderLists.swdd')}}<span class="order_dfhNum" :class="[ radio1 == '1' ? 'active' : '']">({{ this.$store.getters.physicalOrderNum }})</span>
        </el-radio-button>
        <el-radio-button label="2" v-if="handleTabLimits(routerList,'tabPickUpOrder',1)">
          {{$t('orderLists.ztdd')}}
        </el-radio-button>

        <!-- <el-radio-button :label="3">
          虚拟订单
        </el-radio-button>
        <el-radio-button :label="4">
          活动订单<span class="order_dfhNum" :class="[ radio1 == '4' ? 'active' : '']">({{ this.$store.getters.activityOrderNum }})</span>
        </el-radio-button> -->
      </el-radio-group>
    </div>

    <div class="Search">
      <div class="Search-condition">
        <div class="query-input">
          <el-input v-model="inputInfo.orderInfo" size="medium" @keyup.enter.native="demand" class="Search-input" :placeholder="$t('orderLists.qsrddbh')"></el-input>
          <el-input v-model="inputInfo.store" size="medium" @keyup.enter.native="demand" class="Search-input" :placeholder="$t('orderLists.qsrdpmc')"></el-input>
          <el-select class="select-input" v-model="inputInfo.state" :placeholder="$t('orderLists.qxzddzt')">
            <el-option v-for="item in stateList" :key="item.brand_id" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <el-select class="select-input" v-model="inputInfo.type" :placeholder="$t('orderLists.qxzxdzt')">
            <el-option v-for="item in typeList" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <div class="select-date">
            <el-date-picker v-model="inputInfo.date"
              type="datetimerange" :range-separator="$t('reportManagement.businessReport.zhi')"
              :start-placeholder="$t('reportManagement.businessReport.ksrq')"
              :end-placeholder="$t('reportManagement.businessReport.jsrq')"
              value-format="yyyy-MM-dd HH:mm:ss"
              :editable="false">
            </el-date-picker>
          </div>
        </div>
        <div class="btn-list">
          <el-button class="fontColor" @click="reset">{{$t('DemoPage.tableExamplePage.reset')}}</el-button>
          <el-button class="bgColor" type="primary" @click="demand" v-enter="demand">{{$t('DemoPage.tableExamplePage.demand')}}</el-button>
          <span v-for="(item,index) in button_list" :key="index">
            <el-button v-if="item.title == '导出'" class="bgColor export" type="primary" @click="dialogShow">{{$t('DemoPage.tableExamplePage.export')}}</el-button>
          </span>
        </div>
      </div>
	  </div>

    <div class="jump-list">
      <span v-for="(item,index) in button_list" :key="index">
        <el-button v-if="item.title == '代客下单'" class="bgColor laiketui laiketui-add" type="primary"  @click="placeOrder">{{$t('orderLists.dkxd')}}</el-button>
        <el-button v-if="item.title == '打印订单'" class="bgColor el-icon-printer" type="primary"  @click="print">{{$t('orderLists.dddy')}}</el-button>
        <el-button v-if="item.title == '批量发货'" class="bgColor laiketui laiketui-add" type="primary" @click="goBulk"   >{{$t('bulkList.plfh')}}</el-button>
        <el-button v-if="item.title == '批量删除'" class="fontColor" @click="delAll" :disabled="is_disabled" icon="el-icon-delete" >{{$t('orderLists.plsc')}}</el-button>
      </span>
    </div>

    <div class="menu-list" ref="tableFather">
      <el-table :element-loading-text="$t('DemoPage.tableExamplePage.loading_text')" v-loading="loading" :data="tableData" @selection-change="handleSelectionChange" ref="table" class="el-table" style="width: 100%"
		  :height="'85%'">
      <template slot="empty">
          <div class="empty">
            <img src="../../../../assets/imgs/empty.png" alt="" />
            <p style="color: #414658">{{ $t('zdata.zwsj') }}</p>
          </div>
        </template>
        <el-table-column fixed="left" type="selection" width="55">
        </el-table-column>
        <el-table-column prop="orderInfo" :label="$t('orderLists.ddxx')" width="400" align="left">
          <template slot-scope="scope">
            <div class="head-info">
              <span class="red-dot" v-if="scope.row.status == '待发货'"></span>
              <span style="margin-right:1.875rem">{{$t('orderLists.ddbh')}}：{{ scope.row.orderno }}</span>
              <span>{{$t('orderLists.shdd')}}：{{ scope.row.mchOrderNo }}</span>
              <span>{{$t('orderLists.cjsj')}}：{{ scope.row.createDate }}</span>
              <span>{{$t('orderLists.dp')}}：{{ scope.row.mchName }}</span>
            </div>
            <div class="content-info">
              <div class="img-item">
                <img :src="scope.row.goodsImgUrl" alt="" @error="handleErrorImg">
              </div>
              <div class="goods-item">
                <span class="name">{{ scope.row.goodsName }}</span>
                <span><span class="kip_name">{{$t('orderLists.gg')}}：</span>{{ scope.row.attrStr }}</span>
                <span><span class="kip_name">{{$t('orderLists.js')}}：</span>{{ scope.row.needNum}}</span>
                <span><span class="kip_name">{{$t('orderLists.jg')}}：</span>{{ scope.row.goodsPrice }}元</span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="orderPrice" :label="$t('orderLists.ddzj')" width="150">
          <template slot-scope="scope">
            <!-- <span>￥{{scope.row.orderPrice}}</span> -->
            <span>￥{{scope.row.old_total}}</span>

          </template>
        </el-table-column>
        <el-table-column prop="goodsNum" :label="$t('orderLists.sl')" width="150">
        </el-table-column>
        <el-table-column prop="price" :label="$t('orderLists.xdlx')" width="150">
          <template slot-scope="scope">
            <span>{{ scope.row.operation_type == '1' ? $t('orderLists.yhxd') : scope.row.operation_type == '2' ? $t('orderLists.dpxd') : $t('orderLists.ptxd') }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" :label="$t('orderLists.ddzt')" width="150">
          <template slot-scope="scope">
            <span v-if="scope.row.status=='已关闭'">{{ $t('orderLists.ygb') }}</span>
            <span v-if="scope.row.status=='已完成'">{{ $t('orderLists.ywc') }}</span>
            <span v-if="scope.row.status=='待收货'">{{ $t('orderLists.dsh') }}</span>
            <span v-if="scope.row.status=='待发货'">{{ $t('orderLists.dfh') }}</span>
            <span v-if="scope.row.status=='待付款'">{{ $t('orderLists.dfk') }}</span>

          </template>
        </el-table-column>
        <el-table-column prop="name" :label="$t('orderLists.ddlx')" width="150">
          <template slot-scope="scope">
            <span>{{scope.row.otype}}{{$t('orderLists.dd')}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="volume" :label="$t('orderLists.mjxx')" width="200" show-overflow-tooltip>
          <template slot-scope="scope">
            <div class="align">
              <div class="id">
              <span class="id-item">{{$t('orderLists.yhid')}}：</span>
              <span>{{ scope.row.userId }}</span>
            </div>
            <div class="name">
              <span class="name-item">{{$t('orderLists.shr')}}：</span>
              <span>{{ scope.row.userName }}</span>
            </div>
            <div class="name">
              <span class="name-item">{{$t('orderLists.lxdh')}}：</span>
              <span>{{ scope.row.mobile }}</span>
            </div>
            <div class="name">
              <span class="name-item">{{$t('orderLists.shdz')}}：</span>
              <span>{{ scope.row.addressInfo }}</span>
            </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="payName" :label="$t('orderLists.zffs')" width="150">
        </el-table-column>
        <el-table-column v-if="['','1','4'].includes(radio1)" prop="expressStr" :label="$t('orderLists.wlxx')" width="300">
          <template slot-scope="scope">
            <div class="expressStrs">
              <div class="item">
                <div class="item-title">
                  <span>{{$t('orderLists.kddh')}}：</span>
                </div>
                <ul v-if="scope.row.expressList">
                  <li v-for="(item,index) in scope.row.expressList" :key="index">
                    <span>{{ item }}</span>
                  </li>
                </ul>
              </div>
              <div class="item">
                <span class="kuaidi-info">{{$t('orderLists.yf')}}：</span>{{ scope.row.freight }}
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column fixed="right" :label="$t('orderLists.cz')" width="120">
          <template slot-scope="scope">
            <div class="OP-button">
              <div class="OP-button-top">
                <span v-for="(item,index) in button_list" :key="index">
                  <el-button icon="el-icon-view" @click="Details(scope.row)" v-if="item.title == '订单详情'">{{$t('orderLists.ddxq')}}</el-button>
                  <el-button icon="el-icon-edit-outline" @click="Edit(scope.row)"
                    v-if="['待付款','待发货'].includes(scope.row.status) && item.title == '编辑订单'">
                    {{$t('orderLists.bjdd')}}</el-button>
                  <el-button icon="el-icon-box" @click="Delivery(scope.row)" v-if="['','1','4'].includes(radio1) && item.title == '发货'"
                    v-show="['待发货'].includes(scope.row.status)">
                    {{$t('orderLists.spfh')}}</el-button>
                  <el-button icon="el-icon-truck" @click="dialogShow2(scope.row)"
                    v-if="scope.row.courier_num && scope.row.courier_num.length>0 && item.title == '查看物流'" class="logistics">
                    {{$t('orderLists.ckwl')}}</el-button>
                  <!--  http://192.168.0.104:9528/ -->
                  <el-button icon="el-icon-tickets" v-if="scope.row.logistics_type && item.title == '电子面单'" @click="goPage(scope.row)"
                     class="logistics">电子面单</el-button>
                </span>
              </div>
            </div>
		      </template>
        </el-table-column>
	    </el-table>
      <!-- v-if="showPagebox" -->
      <div class="pageBox" ref="pageBox" v-if="showPagebox">
        <div class="pageLeftText">{{$t('DemoPage.tableExamplePage.show')}}</div>
        <el-pagination
          layout="sizes, slot, prev, pager, next"
          :prev-text="$t('DemoPage.tableExamplePage.prev_text')"
          :next-text="$t('DemoPage.tableExamplePage.next_text')"
          @size-change="handleSizeChange"
          :page-sizes="pagesizes"
          :current-page="pagination.page"
          @current-change="handleCurrentChange"
          :total="total"
        >
          <div class="pageRightText">{{$t('DemoPage.tableExamplePage.on_show')}}{{currpage}}-{{current_num}}{{$t('DemoPage.tableExamplePage.twig')}}{{total}}{{ $t('DemoPage.tableExamplePage.twig_notes') }}</div>
        </el-pagination>
      </div>
    </div>

    <div class="dialog-block">
      <!-- 弹框组件 -->
      <el-dialog
        :title="$t('orderLists.wlxx')"
        :visible.sync="dialogVisible2"
        :before-close="handleClose2"
      >
        <el-form :model="ruleForm" ref="ruleForm" label-width="100px" class="demo-ruleForm">
          <div class="task-container" v-for="(item,index) in logisticsList" :key="index">
            <div class="courier-company">
              {{$t('orderLists.kdgs')}}：<span class="span_two">{{ item.kuaidi_name }}</span>
            </div>
            <div class="courier-no">
              {{$t('orderLists.kddh')}}：<span class="span_two">{{ item.courier_num }}</span>
            </div>
            <div class="logistics" v-if="item.list.length == 0">
              {{$t('orderLists.wlgz')}}：<span class="span_two">{{$t('orderLists.zwwl')}}</span>
            </div>
            <div class="logistics" v-else>
              <span class="logistics-tracking">{{$t('orderLists.wlgz')}}：</span>
              <el-timeline>
                <el-timeline-item
                  v-for="(item, index) in item.list"
                  :key="index"
                  :timestamp="item.time">
                  {{item.context}}
                </el-timeline-item>
              </el-timeline>
            </div>
          </div>
        </el-form>
      </el-dialog>
    </div>

    <div class="dialog-export">
      <!-- 弹框组件 -->
      <el-dialog
        :title="$t('DemoPage.tableExamplePage.export_data')"
        :visible.sync="dialogVisible"
        :before-close="handleClose"
      >
        <div class="item" @click="exportPage">
          <i class="el-icon-document"></i>
          <span>{{$t('DemoPage.tableExamplePage.export_page')}}</span>
        </div>
        <div class="item item-center" @click="exportAll">
          <i class="el-icon-document-copy"></i>
          <span>{{$t('DemoPage.tableExamplePage.export_all')}}</span>
        </div>
        <div class="item" @click="exportQuery">
          <i class="el-icon-document"></i>
          <span>{{$t('DemoPage.tableExamplePage.export_query')}}</span>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import orderLists from '@/webManage/js/order/orderList/orderLists'
export default orderLists
</script>

<style scoped lang="less">
@import '../../../../webManage/css/order/orderList/orderLists.less';
</style>
