<template>
  <div class="container">
    <el-form ref="ruleForm" class="form-search" label-width="130px">
        <div class="header">
            <span>{{$t('template.divTemplate.diymb')}}</span>
        </div>
        <div class="div-content" id="iframe_tem">
            <div class="left-show">
                <div class="show-header">
                    <div class="title">
                        <span>{{$t('template.divTemplate.dqyy')}}{{ template }}</span>
                    </div>
                    <div class="editor" @click="editors">
                        <i class="el-icon-edit-outline"></i>
                        <span>{{$t('template.bianji')}}</span>
                    </div>
                </div>
                <div class="show-content" style="width:300px">
                    <iframe :src="H5_domain" id="mobsf" scrolling="auto" frameborder="0" name="refresh_name"></iframe>
                </div>
            </div>
            <div class="right-template">
                <div class="template-header">
                    <div class="title">
                        <span>{{$t('template.divTemplate.mbxz')}}</span>
                    </div>
                </div>
                <div class="template-content">
                    <ul>
                        <li class="default">
                            <img src="../../../assets/imgs/default.png">
                            <div class="operation">
                                <div class="btn-item">
                                    <el-button type="primary" v-if="!is_default" @click="Application('默认')">{{$t('template.divTemplate.yy')}}</el-button>
                                    <el-button class="edit" type="primary"  @click="$router.push('/plug_ins/template/playlist')">{{$t('template.bianji')}}</el-button>
                                </div>
                            </div>
                            <p class="default-p">{{$t('template.divTemplate.mrmb')}}</p>
                        </li>
                        <li v-for="(item,index) in imgList" :key="index">
                            <img :src="item.cover">
                            <div class="operation">
                                <div class="btn-item">
                                    <el-button type="primary" v-if="item.status == 0" @click="Application(item)">{{$t('template.divTemplate.yy')}}</el-button>
                                    <el-button class="edit" type="primary"  @click="editor(item)">{{$t('template.bianji')}}</el-button>
                                    <el-button class="del" type="primary"  @click="Delete(item)">{{$t('template.shanchu')}}</el-button>
                                </div>
                            </div>
                            <p class="default-p">{{ item.name }}</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </el-form>
  </div>
</template>

<script>
import divTemplate from '@/webManage/js/plug_ins/template/divTemplate'
export default divTemplate
</script>

<style scoped lang='less'>
@import '../../../webManage/css/plug_ins/template/divTemplate.less';
</style>