<template>
  <div class="order_detail_page">
      <div class="big_title">基本信息</div>
      <el-button @click="getOrderInfoFn">click me</el-button>
      <ul class="info_list_con">
         
          <li>
              <div class="item">
                  <div class="tit">订单类型</div>
                  <div class="txt"> {{ orderInfo.orderType | orderTypeFn }}</div>
              </div>
              <div class="item">
                  <div class="tit">母订单号</div>
                  <div class="txt"> {{ orderInfo.orderParentNo }}</div>
              </div>
              <div class="item">
                  <div class="tit">子订单号</div>
                  <div class="txt"> {{  orderInfo.orderNo }} </div>
              </div>
              <div class="item">
                  <div class="tit">订单状态</div>

                  <div class="txt"> {{  orderInfo.status | orderStatusFn }} </div>
              </div>
              <div class="item">

                  <div class="tit">订单来源</div>

                  <div class="txt"> {{  orderInfo.source | sourceFn  }} </div>
              </div>
              <div class="item">
                    <div class="tit">服务商</div>
                    <div class="txt"> 
                        {{ orderInfo.provice?orderInfo.provice:"----"  }} 
                        {{ orderInfo.city?orderInfo.city:"----"  }} 
                        
                        {{  orderInfo.userName?orderInfo.userName:"----" }}
  
                      
                    </div>
              </div>
              <div class="item">
                  <div class="tit">渠道</div>

                  <div class="txt"> {{ orderInfo.channel?orderInfo.channel:"----" }} </div>
              </div>
              <div class="item">
                  <div class="tit">品牌</div>

                  <div class="txt"> {{  orderInfo.brandName?orderInfo.brandName:"----" }} </div>
              </div>
              <div class="item">
                  <div class="tit">生产工厂</div>
                  <div class="txt">{{ orderInfo.mchName?orderInfo.mchName:"----" }}</div>
              </div>
          </li>
 
          <li>
              <div class="item">
                  <div class="tit">支付方式</div>
                  <div class="txt">{{ orderInfo.payType | payTypeFn }}</div>
              </div>
              <div class="item">
                  <div class="tit">订单总金额</div>
                  <div class="txt"> {{  orderInfo.payPrice?orderInfo.payPrice:"----" }} </div>
              </div>
              <!-- <div class="item">
                  <div class="tit">退款金额</div>
                  <div class="txt"> ----</div>
              </div> -->
              <div class="item">
                
                  <div class="tit">供货总额</div>
                  <div class="txt"> {{ orderInfo.totalPrice?orderInfo.totalPrice:"----" }} </div>
              </div>
          </li>


          <li>
              <div class="item">
                  <div class="tit">采购总价</div>
                  <div class="txt">{{ orderInfo.totalCostPrice?orderInfo.totalCostPrice:"----" }}</div>
              </div>
              <!-- <div class="item">
                  <div class="tit">售后费用</div>
                  <div class="txt"> ---- </div>
              </div> -->
              <div class="item">
                  <div class="tit">税费总额</div>
                  <div class="txt">{{ orderInfo.taxation && orderInfo.taxation>0 ?orderInfo.taxation: 0 }}</div>
              </div>
          </li>
      </ul>

      <div class="big_title">商品详情</div>
       
      <el-table  :data="goodArr"   style="width: 100%"          
          :header-cell-style="{textAlign:'center'}"
          :cell-style="{textAlign:'center'}"
          class="order_good_table">
          <el-table-column prop="productCode" label="商品编码" width="350"></el-table-column>
          <el-table-column prop="costPrice" label="采购单价(元)" width="200"></el-table-column>
          <el-table-column prop="supplierPrice" label="服务商供货单价(元)" width="200" ></el-table-column>
          <el-table-column prop="num" label="数量" width="100"></el-table-column> 
      </el-table>
      
      <!-- <div class="big_title">订单处理流程</div> -->

      <!-- <div class="record_con">
          <el-timeline>
              <el-timeline-item timestamp="2018/4/12" placement="top">
              <el-card>
                  <h4>提交</h4>
                  <p> 提交于 2018/4/12 20:46</p>
                  
                  <el-table :data="orderTimeGoodTable" style="width: 29%;margin-top:10px;" :border="true">
                      <el-table-column
                          prop="goodName"
                          label="商品"
                          width="250">
                      </el-table-column>
                      <el-table-column
                          prop="count"
                          label="数量">
                      </el-table-column>
                  </el-table>
              </el-card>
              </el-timeline-item>
              <el-timeline-item timestamp="2018/4/3" placement="top">
              <el-card>
                  <h4>提交</h4>
                  <p> 提交于 2018/4/3 20:46</p>
              </el-card>
              </el-timeline-item>
              <el-timeline-item timestamp="2018/4/2" placement="top">
              <el-card>
                  <h4>提交</h4>
                  <p> 提交于 2018/4/2 20:46</p>
              </el-card>
              </el-timeline-item>
          </el-timeline>
      </div> -->


    
      <el-dialog
          title="期望发货时间"
          :visible.sync="changeTimedialogVisible"

          width="31%"
          :center="true"
          :before-close="handleCloseChangeTimeFn">
          
          <div class="order_info_item">
              <div class="title">期望时间:</div>
              <el-date-picker v-model="dateStr" type="datetime" placeholder="选择日期" class="text" @change="selectDateFn"></el-date-picker>
          </div>
          <div class="order_info_item">
              <div class="title">跟单备注:</div>
              
              <el-input type="textarea"  :autosize="{ minRows: 5}" placeholder="请输入内容" v-model="remark" class="text"></el-input>
          </div>
          <span slot="footer" class="dialog-footer">
               
              <el-button @click="changeTimedialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="changeTimedialogVisible = false">确 定</el-button>
          </span>
      </el-dialog>


      <el-dialog
          title="修改收货地址"
          :visible.sync="changeUserInfodialogVisible"

          width="31%"
          :center="true"
          :before-close="handleCloseChangeTimeFn">
          
          <div class="order_info_item">
              <div class="title">所在地区:</div>
              <el-date-picker v-model="dateStr" type="datetime" placeholder="选择日期" class="text" @change="selectDateFn"></el-date-picker>
          </div>
          <div class="order_info_item">
              <div class="title">详细地址:</div>
              
              <el-input type="textarea"  :autosize="{ minRows: 5}" placeholder="请输入内容" v-model="remark" class="text"></el-input>
          </div>
          <div class="order_info_item">
              <div class="title">收货人:</div>
              <el-input type="text"   placeholder="请输入姓名" v-model="remark" class="text"></el-input>
          </div>

          <div class="order_info_item">
              <div class="title">手机号码:</div>
              <el-input type="text"    placeholder="请输入手机号" v-model="remark" class="text"></el-input>
          </div>
          <span slot="footer" class="dialog-footer">
               
              <el-button @click="changeUserInfodialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="changeUserInfodialogVisible = false">确 定</el-button>
          </span>
      </el-dialog>
  </div>
</template>

<script>


import {  orderDetailsInfo } from '@/api/order/orderList';
export default {
  data () {
      return {
          orderNo: "",
          goodArr: [{}],
          orderTimeGoodTable: [
              {
                  goodName: 'LKS8821-E+F+E-3RW',
                  count: 1
              }, 
              {  
                  goodName: 'LK-X2208-XXY',
                  count: 1
              }

          ],
          multipleSelection: [],
          activities: [
              {
                  content: '活动按期开始',
                  timestamp: '2018-04-15'
              }, 
              {
                  content: '通过审核',
                  timestamp: '2018-04-13'
              }, 
              {
                  content: '创建成功',
                  timestamp: '2018-04-11'
              }
          ],
          orderInfo: "",
          // 期望发货时间
          changeTimedialogVisible: false,
          // 收货人信息弹窗
          changeUserInfodialogVisible: false,

      }
  },
  mounted () {  
      this.$nextTick(function () {
          this.init()
      })
  },
  methods: {
      init: function () {
          let orderNo = window.location.href.split("orderNo=")[1];   
          this.orderNo = orderNo;
          this.getOrderInfoFn()
      },
      handleCloseChangeTimeFn: function () {
          this.changeTimedialogVisible = false;
      },
      getOrderInfoFn: function () {
          let _this = this;
          orderDetailsInfo({
              api: "admin.orderV2.examineOrderDetails",
              status:  this.status,
              orderNo: this.orderNo
          }).then((res)=> {
              console.log("--------getOrderInfoFn")
              console.log(res.data.data)
              console.log("--------getOrderInfoFn")

              let resData = res.data.data;   
              if (resData) {
                   _this.orderInfo = resData;
              
                   _this.goodArr = resData.details;
              }
          })              
      }    
  },

  filters: {

     
        // 订单类型
        orderTypeFn: function (status) { 
           switch (status) {
                case 1:
                    return "自营订单";
                    break ;
                case 2:
                    return "pop";
                    break ;
                
                default:
                    return "----";
                    break ;
           }
        },

        orderStatusFn: function (status) {
            switch (status) {

                case 0:
                    return "已取消";
                    break ;

                case 1:
                    return "待付款";
                    break ;
                case 2:
                    return "待确认";
                    break ;
                case 3: 
                    return "待发货";
                    break ;
                case 4:
                    return "可发货";    
                    break ;

                case 5:
                    return "已发货";
                    break ;
                default:
                    return "----";
                    break ;
            }
        },
        sourceFn: function (status) {
            switch (status) {
                case 1: 
                   return "珞珂家居PC端";
                   break;
                default:
                   return "----";

                   break;
            }
        },
        payTypeFn: function (status) {

            switch (status) {
                
                case 1:
                return  "结算通";
                break ;
                case 2:
                return  "余额支付";
                
                break ;

                
                case 3:
                return  "线下汇款";
                break ;
                case 4:
                return  "线下汇款+余额支付";
                break ;
                default: 
                return "----";
                break ;
            }
        }
  }
}
</script>



<style>
@import "./index.css";
</style>
