<template>
  <div class="container">
    <div class="Search">
      <div class="Search-condition">
        <div class="query-input">
          <el-input
            v-model="inputInfo.userName"
            size="medium"
            @keyup.enter.native="demand"
            class="Search-input"
            :placeholder="$t('pointManagement.qsryh')"
          ></el-input>
          <div class="select-date">
            <el-date-picker
              v-model="inputInfo.date"
              type="datetimerange"
              :range-separator="$t('reportManagement.businessReport.zhi')"
              :start-placeholder="$t('reportManagement.businessReport.ksrq')"
              :end-placeholder="$t('reportManagement.businessReport.jsrq')"
              value-format="yyyy-MM-dd HH:mm:ss"
              :editable="false"
            >
            </el-date-picker>
          </div>
        </div>
        <div class="btn-list">
          <el-button class="fontColor" @click="reset">{{
            $t('DemoPage.tableExamplePage.reset')
          }}</el-button>
          <el-button class="bgColor" type="primary" @click="demand" v-enter="demand">{{
            $t('DemoPage.tableExamplePage.demand')
          }}</el-button>
          <span v-for="(item, index) in button_list" :key="index">
            <el-button
              v-if="item.title == '导出'"
              class="bgColor export"
              type="primary"
              @click="dialogShow"
              >{{$t('DemoPage.tableExamplePage.export')}}</el-button
            >
          </span>
        </div>
      </div>
    </div>


    <div class="menu-list" ref="tableFather">
        <el-table :data="orderListArr" style="width: 100%">
              <el-table-column prop="orderNoInfo" label="子单号" width="200">
                  <template slot-scope="scope">
                      <div>
                          <p>{{ scope.row.orderNoInfo.orderNo }}</p>
                          <p>子单金额:{{ scope.row.orderNoInfo.taxation }}</p>
                      </div>
                  </template>
              </el-table-column>
              <el-table-column prop="name" label="母单号" width="200">
                  <template slot-scope="scope">
                      <div>
                          <p>{{ scope.row.orderParentNoInfo.orderParentNo }}</p>
                          <p>母单金额: {{ scope.row.orderParentNoInfo.opTotalPrice }}</p>
                      </div>
                  </template>
              </el-table-column>

              <el-table-column prop="source" label="订单来源" width="80">
                  <template slot-scope="scope">
                      <div>
                          <p>{{ scope.row.source | sourceFn }}</p>
                        
                      </div>
                  </template>
              </el-table-column>
              <el-table-column prop="channel" label="渠道" width="100">

                  <template slot-scope="scope">
                    <div>
                        {{ scope.row.channel?scope.row.channel:"----" }}
                    </div>
                </template>
              </el-table-column>
              <el-table-column prop="brands" label="品牌" width="80">
                  <template slot-scope="scope">
                    <div>

                        {{ scope.row.brandName?scope.row.brandName:"----" }}
                    </div>
                  </template>
              </el-table-column>
              
              <el-table-column prop="factoryAddress" label="服务商" width="200">
                  <template slot-scope="scope">  
                    <div>
                        <p>
                            {{ scope.row.factoryAddress.provice?scope.row.factoryAddress.provice:"----" }} 
                            {{ scope.row.factoryAddress.city?scope.row.factoryAddress.city:"----" }} 
                            {{ scope.row.factoryAddress.area?scope.row.factoryAddress.area:"----" }} 
                            {{ scope.row.factoryAddress.address?scope.row.factoryAddress.address:"----" }}
                        </p>
                        <p> {{ scope.row.factoryAddress.name?scope.row.factoryAddress.name:"----" }} </p>
                        <p>{{ scope.row.factoryAddress.mobile?scope.row.factoryAddress.mobile:"----" }}</p>
                    </div>
                </template>
              </el-table-column>
              
             
              <el-table-column prop="payTypeInfo" label="支付方式" width="80">
                  <template slot-scope="scope">
                      <div>
                          <p>{{  scope.row.payTypeInfo.payType | payTypeFn}}</p>    
                          <p>{{  scope.row.payTypeInfo.offlinePayTime?scope.row.payTypeInfo.offlinePayTime:"----" }}</p>
                          <p><img :src=" scope.row.payTypeInfo.offlinePayImg " alt=""/></p>       
                      </div>
                    </template>
              </el-table-column>

              <el-table-column prop="settlementType" label="结算方式" width="80">
                  <template slot-scope="scope">
                      <div>
                          {{ scope.row.settlementType  | settlementTypeFn }}
                      </div>
                  </template>
              </el-table-column>
              
              <el-table-column prop="status" label="订单状态" width="80">

                <template slot-scope="scope">
                    <div>{{ scope.row.status | orderStatusFn}}</div>

                </template>
              </el-table-column>
              <el-table-column prop="times" label="时间管理" width="150">
                  <template slot-scope="scope">
                      <div>
                          <p>下单时间: {{ scope.row.times.createTime?scope.row.times.createTime:"-----" }}</p>
                      
                          <p>期望发货时间: {{ scope.row.times.expectedTime?scope.row.times.expectedTime:"----" }}</p>
                      </div>
                  </template>
              </el-table-column>
              <el-table-column prop="totalCostPrice" label="采购总额(元)" width="100"></el-table-column>
              <el-table-column prop="totalPrice" label="供货总额(元)" width="100"></el-table-column>
              <el-table-column prop="opTaxation" label="税费总额(元)" width="100"></el-table-column>

              <el-table-column prop="date" label="操作">
                  <template slot-scope="scope">
                        <div class="operate_btn_group">
                            <div class="btn check_btn"  @click="showUploadPayFn(scope.row)">审核支付</div>
                            <router-link :to="'/finance/pointSet/pointDetails?orderNo=' +  scope.row.orderNoInfo.orderNo ">订单详情 </router-link>
                            <div class="btn">审核详情</div>
                        </div>
                    </template>
              </el-table-column>
      </el-table>
      <div class="pageBox" ref="pageBox"  >
        <!-- handleCurrentChange -->

        <el-pagination
          class="page_con"
          layout="slot, prev, pager, next"
          :prev-text="$t('DemoPage.tableExamplePage.prev_text')"
          :next-text="$t('DemoPage.tableExamplePage.next_text')"
          @size-change="handleSizeChange"
          :page-sizes="pagesizes"
          :current-page="pagination.page"
          @current-change="changePageFn"

          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <div class="dialog-export">
     
    </div>

       
    <el-dialog
            title="上传支付凭证"
            :visible.sync="uploadPayDialogVisible"
            width="50%"
            :center="true"
            :before-close="handleClose">
            <el-form ref="form" :model="uploadPayForm" label-width="80px" class="upload_form"    style="height:500px;overflow:auto;">
                <el-form-item label="订单编号">
                     {{ this.currentOrderItem?this.currentOrderItem.orderNoInfo.orderNo:"----" }}
                </el-form-item>
                <el-form-item label="下单时间">
                     {{ this.currentOrderItem?this.currentOrderItem.times.createTime:"----" }}
                </el-form-item>
                <el-form-item label="订单来源">
                    <p>{{  this.currentOrderItem.source|sourceFn }} </p>
                </el-form-item>
                <!-- <el-form-item label="收货地址">
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.provice:"-----" }}        
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.city:"----" }}
                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.area:"----" }}

                    {{ this.currentOrderItem?this.currentOrderItem.deliveryAddress.address:"----" }}
                </el-form-item> -->
                <el-form-item label="订单金额">
                     {{ this.currentOrderItem.totalPrice }} 元
                </el-form-item>

                <el-form-item label="审核留言">
                    <el-input type="textarea" v-model="uploadPayForm.desc"></el-input>
                </el-form-item>

                <div class="line"></div>

                <el-form-item label="收款截图">
                    <el-upload
                        action="https://jsonplaceholder.typicode.com/posts/"
                        list-type="picture-card"
                    >
                        <i class="el-icon-plus"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="付款人">
                    <el-input v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
                <el-form-item label="收款银行">
                    <el-input v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
                <el-form-item label="应收金额">
                    <el-input  v-model="this.currentOrderItem.totalPrice" :disabled="true"></el-input>
                </el-form-item> 

                <el-form-item label="线下转账">
                    <el-input v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
                <el-form-item label="收款时间">
                    <el-date-picker  v-model="uploadPayForm.desc" type="date" placeholder="选择日期"></el-date-picker>
                    <p>为了系统和财务统计一致，请认真选择支付时间!</p>
                </el-form-item>
                <el-form-item label="支付方式">
                    <el-select v-model="uploadPayForm.payType" placeholder="请选择活动区域" @change="selectPayTypeFn">
                        <el-option :label="payTypeItem.title" :value="payTypeItem.value" v-for="(payTypeItem, index) in uploadPayForm.payTypeArr"></el-option>  
                    </el-select>
                </el-form-item>

                <el-form-item label="结款类型">
                    <el-select v-model="uploadPayForm.paymentType" placeholder="请选择活动区域" @change="selectPaymentTypeFn">
                        <el-option :label="payTypeItem.title" :value="payTypeItem.value" v-for="(payTypeItem, index) in uploadPayForm.paymentTypeArr"></el-option>                       
                    </el-select>
                </el-form-item>

                <el-form-item label="备注">
                    <el-input type="textarea" v-model="uploadPayForm.desc"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="uploadPayDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirmUploadPayFn">确 定</el-button>
            </span>
        </el-dialog>
  </div>
</template>

<script>
import pointManagement from '@/webManage/js/finance/withdrawalManage/pointManagement'
import { pointList } from '@/api/finance/withdrawalManage'
import { exports } from '@/api/export/index'
import { mixinstest } from '@/mixins/index'
import { getStorage } from '@/utils/storage'
import { getButton } from '@/api/layout/information'

import {  orderList } from '@/api/finance/withdrawalManage';
export default {
  name: 'pointManagement',
  mixins: [mixinstest],
  data () {
    return {
      inputInfo: {
        userName: null,
        date:null,
      },
      loading: true,
      // table高度
      tableHeight: null,
      button_list: [],
      // 导出弹框数据
      dialogVisible: false,
      orderListArr: [],
      total: 0,
      pageNum: 1,
      pageSize: 10,
      currentOrderItem: "",

      uploadPayDialogVisible: false, // 审核支付
      uploadPayForm: {
                payType: "", // 支付方式
                payTypeArr: [
                    {

                        id: 0,

                        title: "银行转账",
                        value: 1
                    }
                ],
                paymentType: "",  // 结款类型
                paymentTypeArr: [
                    {

                        id: 0,
                        
                        title: "现款结清",
                        value: 1
                    },
                    {
                        id: 1,
                        title: "线上转账",
                        value: 2
                    }
                ]
      } 
    }
  },

  created () {
    this.getButtons()
    this.axios()
  },

  mounted () {
    this.$nextTick(function () {
      //this.getHeight()
        this.getOrderListFn()
    })
    window.addEventListener('resize', this.getHeight(), false)
  },


  methods: {
    getOrderListFn () {
          let _this = this;
          orderList({
                api: "admin.orderV2.purchaseList",
                orderParentStatus: 2,
                pageNum: this.pageNum,
                pageSize: this.pageSize
                //  pageSize: 4
          }).then((res)=> {
                let resData = res.data.data;      
               
                if (resData) { 
               
               
                  let resOrderArr = resData.records;
                    let orderListArr = []; 
                    resOrderArr.forEach((orderItem, index)=> {
                        let item = {}
                        item.orderNoInfo = {
                            orderNo: orderItem.orderNo,

                            taxation: orderItem.taxation,
                        }
                        item.orderParentNoInfo = {
                            orderParentNo: orderItem.orderParentNo,
                            opTotalPrice: orderItem.opTotalPrice,
                            orderNoCount: "----"
                        }

                        item.source = orderItem.source; 
                        item.channel = orderItem.channel;
                        item.brands = orderItem.brands;
                        item.factoryAddress = orderItem.factoryAddress;
                        item.payTypeInfo = {
                           payType: orderItem.payType,
                           offlinePayTime: orderItem.offlinePayTime,
                           offlinePayImg: orderItem.offlinePayImg
                        }
                        item.settlementType = orderItem.settlementType;
                        item.status = orderItem.status;
                        item.times = {
                            createTime: orderItem.createTime, // 下单时间
                            expectedTime: orderItem.expectedTime
                        }
                        item.totalCostPrice = orderItem.totalCostPrice;
                        item.totalPrice = orderItem.totalPrice;
                        item.opTaxation = orderItem.opTaxation;
                        orderListArr.push(item);
                    })

                    _this.orderListArr = orderListArr;
                    _this.total = resData.total;
                }
            })
    },
    showUploadPayFn: function (orderItem) {
      
            this.uploadPayDialogVisible = true;
            this.currentOrderItem = orderItem;
            console.log("currentOrderItem")

            console.log(this.currentOrderItem)


            console.log("currentOrderItem")
    },
    //获取按纽权限
    async getButtons () {
      let route = getStorage('route')
      route.forEach(item => {
        if (item.path == 'salesReturn') {
          return (this.menuId = item.id)
        }
      })
      let buttonList = await getButton({
        api: 'saas.role.getButton',
        menuId: this.menuId
      })
      this.button_list = buttonList.data.data
    },
    // 重置
    reset () {
      this.inputInfo.userName = null
      this.inputInfo.date = null
    },

    // 查询
    demand () {
      this.currpage = 1
      // this.current_num = 10
      this.showPagebox = false
      this.loading = true
      this.dictionaryNum = 1
      this.axios().then(() => {
        this.loading = false
        if (this.tableData.length > 5) {
          this.showPagebox = true
        }
      })
    },

    View (value) {
      this.$router.push({
        path: '/finance/pointSet/pointDetails',
        query: {
          id: value.user_id
        }
      })
    },

    //选择一页多少条
    handleSizeChange (e) {
      this.loading = true
      // this.current_num = e
      this.pageSize = e
      this.axios().then(() => {
        this.currpage = (this.dictionaryNum - 1) * this.pageSize + 1
        this.current_num =
          this.tableData.length === this.pageSize
            ? this.dictionaryNum * this.pageSize
            : this.total
        this.loading = false
      })
    },




    changePageFn (page) {
        console.log(page)
        this.pageNum = page;

        this.getOrderListFn()
    },
    //点击上一页，下一页
    handleCurrentChange (e) {
      this.loading = true
      this.dictionaryNum = e
      this.currpage = (e - 1) * this.pageSize + 1
      this.axios().then(() => {
        this.current_num =
          this.tableData.length === this.pageSize
            ? e * this.pageSize
            : this.total
        this.loading = false
      })
    },

    // 导出弹框方法
    dialogShow () {
      this.dialogVisible = true
    },

    handleClose (done) {
      this.dialogVisible = false
    },

    async exportPage () {
      exports(
        {
          api: 'admin.user.getUserIntegralInfo',
          pageNo: this.dictionaryNum,
          pageSize: this.pageSize,
          exportType: 1,
          userName: this.inputInfo.userName,
          startDate: this.inputInfo.date?.[0] ?? '',
          endDate: this.inputInfo.date?.[1] ?? ''
        },
        '积分管理_导出本页'
      )
    },

    async exportAll () {
      exports(
        {
          api: 'admin.user.getUserIntegralInfo',
          pageNo: 1,
          pageSize: 9999,
          exportType: 1
        },
        '积分管理_导出全部'
      )
    },

    async exportQuery () {
      exports(
        {
          api: 'admin.user.getUserIntegralInfo',
          pageNo: 1,
          pageSize: this.total,
          exportType: 1,
          userName: this.inputInfo.userName,
          startDate: this.inputInfo.date?.[0] ?? '',
          endDate: this.inputInfo.date?.[1] ?? ''
        },
        '积分管理_导出查询'
      )
    }
  },

  filters: {
         // 结算类型 
         settlementTypeFn: function (status) {
            switch (status) {
                case 1:

                    return "现结";
                    break ;
                default:
                    
                     
                    return "----";
                    break ;
            }
        },
        payTypeFn: function (status) {

            switch (status) {
                
                case 1:
                  return  "结算通";
                  break ;
                case 2:
                  return  "余额支付";
                  
                  break ;

                   
                case 3:
                  return  "线下汇款";
                  break ;
                case 4:
                  return  "线下汇款+余额支付";
                  break ;
                default: 
                  return "----";
                  break ;
            }
        },
        sourceFn: function (status) {
            switch (status) {
                case 1: 
                   return "珞珂家居PC端";
                   break;
                default:
                   return "----";

                   break;
            }
        },
        orderStatusFn: function (status) {
            switch (status) {

                case 0:
                    return "已取消";
                    break ;

                case 1:
                    return "待付款";
                    break ;
                case 2:
                    return "待确认";
                    break ;
                case 3: 
                    return "待发货";
                    break ;
                case 4:
                    return "可发货";    
                    break ;

                case 5:
                    return "已发货";
                    break ;
                default:
                    return "----";
                    break ;
            }
        }
    }
}

</script>

<style scoped lang="less">
@import '../../../webManage/css/finance/withdrawalManage/pointManagement.less';
.operate_btn_group .btn,
.operate_btn_group a{
    color: #00c0ff;
    cursor: pointer;
}
.pageBox{
  
}
.page_con{
  display: flex;
  flex-direction: row;
  justify-content:center;
  text-align:center;
}






.operate_btn_group .check_btn{
   color: red;
}
</style>
