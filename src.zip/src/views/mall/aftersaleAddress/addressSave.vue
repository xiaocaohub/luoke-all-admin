<template>
  <div class="container">
    <div class="add-menu">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm"  class="picture-ruleForm" label-width="auto">
        <el-form-item :label="$t('aftersaleAddress.lxr')" prop="name">
          <el-input v-model="ruleForm.name" :placeholder="$t('aftersaleAddress.add.qsrlxr')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('aftersaleAddress.lxdh')" prop="tel">
          <el-input v-model="ruleForm.tel" :placeholder="$t('aftersaleAddress.add.qsrlxdh')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('aftersaleAddress.add.szdq')" prop="sheng">
          <el-select class="select-input" v-model="ruleForm.sheng" :placeholder="$t('aftersaleAddress.add.sheng')">
            <el-option v-for="(item,index) in shengList" :key="index" :label="item.g_CName" :value="item.g_CName">
              <div @click="getShi(item.groupID)">{{ item.g_CName }}</div>
            </el-option>
          </el-select>
          <el-select class="select-input" v-model="ruleForm.shi" :placeholder="$t('aftersaleAddress.add.shi')">
            <el-option v-for="(item,index) in shiList" :key="index" :label="item.g_CName" :value="item.g_CName">
              <div @click="getXian(item.groupID)">{{ item.g_CName }}</div>
            </el-option>
          </el-select>
          <el-select class="select-input" v-model="ruleForm.xian" :placeholder="$t('aftersaleAddress.add.xian')">
            <el-option v-for="(item,index) in xianList" :key="index" :label="item.g_CName" :value="item.g_CName">
              <div>{{ item.g_CName }}</div>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item  :label="$t('aftersaleAddress.xxdz')" prop="address">
          <el-input v-model="ruleForm.address" :placeholder="$t('aftersaleAddress.add.qsrxxdz')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('aftersaleAddress.yzbm')" prop="code">
          <el-input v-model="ruleForm.code" :placeholder="$t('aftersaleAddress.add.qsryzbm')" @keyup.native="ruleForm.code = oninput2(ruleForm.code)"></el-input>
        </el-form-item>
        <el-form-item :label="$t('aftersaleAddress.sfmr')" prop="is_default">
          <el-radio-group v-model="ruleForm.is_default">
            <el-radio v-model="ruleForm.is_default" :label="1">{{$t('aftersaleAddress.Yes')}}</el-radio>
            <el-radio v-model="ruleForm.is_default" :label="0">{{$t('aftersaleAddress.No')}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <div class="form-footer">
          <el-form-item>
            <el-button class="bgColor" type="primary" @click="submitForm('ruleForm')">{{ $t('DemoPage.tableFromPage.save') }}</el-button>
            <el-button class="bdColor" @click="$router.go(-1)" plain>{{ $t('DemoPage.tableFromPage.cancel') }}</el-button>
          </el-form-item>
        </div>
      </el-form>
    </div>
  </div>
</template>


<script>
import addressSave from "@/webManage/js/mall/aftersaleAddress/addressSave";
export default addressSave
</script>

<style scoped lang="less">
  @import "../../../webManage/css/mall/aftersaleAddress/addressSave.less";
</style>
