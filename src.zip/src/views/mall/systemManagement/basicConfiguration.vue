<template>
  <div class="container">
    <!-- <div class="btn-nav" >
      <el-radio-group fill="#2890ff" text-color="#fff" v-model="radio1">
        <el-radio-button
          :label="$t('systemManagement.jcpz')"
          @click.native.prevent="$router.push('/mall/basicConfiguration')"
        ></el-radio-button>
        <el-radio-button
          :label="$t('systemManagement.xypz')"
          @click.native.prevent="tabJump()"
        ></el-radio-button>
        <el-radio-button
          :label="$t('systemManagement.cjwt')"
          @click.native.prevent="$router.push('/mall/commonProblem')"
        ></el-radio-button>
        <el-radio-button
          :label="$t('systemManagement.xszn')"
          @click.native.prevent="$router.push('/mall/newbieGuide')"
        ></el-radio-button>
        <el-radio-button
          :label="$t('systemManagement.shfw')"
          @click.native.prevent="$router.push('/mall/afterSales')"
        ></el-radio-button>
        <el-radio-button
          :label="$t('systemManagement.gywm')"
          @click.native.prevent="$router.push('/mall/aboutUs')"
        ></el-radio-button>
      </el-radio-group>
    </div> -->
    <div class="basic-configuration">
      <!-- <div class="header">
        <span>基本信息</span>
      </div> -->

      <el-form
        :model="ruleForm"
        :rules="rules"
        label-position="right"
        ref="ruleForm"
        label-width="auto"
        class="form-search"
      >
        <div>
          <!-- <el-form-item :label="$t('systemManagement.sfzc')" required>
            <el-radio-group disabled v-model="ruleForm.is_Registered">
              <el-radio
                v-for="item in isRegisteredList"
                :label="item.value"
                :key="item.value"
                >{{ item.name }}</el-radio
              >
            </el-radio-group>
            <span class="prompt">{{$t('systemManagement.dycbc')}}</span>
          </el-form-item> -->
          <!-- <el-form-item :label="$t('systemManagement.gslo')" prop="companyLogo" required>
            <l-upload
              :limit="1"
              v-model="ruleForm.companyLogo"
              :text="$t('systemManagement.jy100')"
            >
            </l-upload>
          </el-form-item>
          <el-form-item :label="$t('systemManagement.wxmr')" prop="headImg" required>
            <l-upload
              :limit="1"
              v-model="ruleForm.headImg"
              :text="$t('systemManagement.jy100')"
            >
            </l-upload>
          </el-form-item> -->
          <div class="form-card">
            <div class="title">{{ $t("systemManagement.qdpz") }}</div>
            <el-form-item :label="$t(`systemManagement.pcdpdz`)">
              <el-input
                v-model="ruleForm.pcMchPath"
                style="width: 370px"
              ></el-input>
              <span class="prompt"
                >（{{ $t("systemManagement.tspcmchpath") }}）</span
              >
            </el-form-item>
            <el-form-item
              :label="$t('systemManagement.diyyl')"
              prop="h_Address"
            >
              <el-input
                v-model="ruleForm.h_Address"
                style="width: 370px"
              ></el-input>
              <span class="prompt"
                >（{{ $t(`systemManagement.yddtishi`) }}）</span
              >
            </el-form-item>
            <el-form-item :label="$t('systemManagement.qdxx')">
              <el-input
                @keyup.native="
                  ruleForm.front_message = oninput2(ruleForm.front_message)
                "
                v-model="ruleForm.front_message"
                style="width: 370px"
              >
                <template slot="append">{{
                  $t("systemManagement.day")
                }}</template>
              </el-input>
              <!-- <span class="prompt">{{ $t("systemManagement.wkzb") }}</span> -->
              <span class="prompt"
                >（{{ $t(`systemManagement.znxxtshi`) }}）</span
              >
            </el-form-item>
            <el-form-item :label="$t('systemManagement.ydddl')">
              <el-input
                v-model="ruleForm.login_validity"
                @keyup.native="
                  ruleForm.login_validity = oninput2(ruleForm.login_validity)
                "
                style="width: 370px"
              >
                <template slot="append">{{
                  $t("systemManagement.hour")
                }}</template>
              </el-input>
              <span class="prompt"
                >（{{ $t(`systemManagement.yddyhtishi`) }}）</span
              >
            </el-form-item>
            <!-- 客服 -->
            <!-- <el-form-item :label="$t('systemManagement.kf')">
            <el-input
              type="textarea"
              :rows="3"
              v-model="ruleForm.service"
              placeholder=""
              style="width: 370px"
            ></el-input>
          </el-form-item> -->
          <!-- 腾讯位置配置去除 -->
            <!-- <el-form-item :label="$t('systemManagement.txwz')" prop="tx_key">
              <el-input
                v-model="ruleForm.tx_key"
                style="width: 370px"
              ></el-input>
              <span class="prompt"
                >（{{ $t(`systemManagement.lbsdwtishi`) }}）</span
              >
            </el-form-item> -->
          </div>
          <!-- 搜索配置 -->
          <div class="form-card">
            <div class="title">{{ $t(`systemManagement.gtpz`) }}</div>
            <el-form-item :label="$t('systemManagement.unip')">
              <!-- <el-switch
                v-model="ruleForm.is_unipush"
                :active-value="1"
                :inactive-value="0"
                active-color="#00ce6d"
                inactive-color="#d4dbe8"
              >
              </el-switch> -->
              <div class="iframe-row-card">
                <div style="margin: 22px 0 22px 0">
                  <!-- <div class="card-row-left">Appkey</div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.Appkey"></el-input>
                  </div> -->
                  <el-form-item label="Appkey" :label-width="language==='en'?'170px':'100px'">
                    <el-input v-model="ruleForm.Appkey"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <!-- <div class="card-row-left">Appid</div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.Appid"></el-input>
                  </div> -->
                  <el-form-item label="Appid" :label-width="language==='en'?'170px':'100px'">
                    <el-input v-model="ruleForm.Appid"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <!-- <div class="card-row-left">MasterECRET</div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.MasterECRET"></el-input>
                  </div> -->
                  <el-form-item label="MasterECRET" :label-width="language==='en'?'170px':'100px'">
                    <el-input v-model="ruleForm.MasterECRET"></el-input>
                  </el-form-item>
                </div>
              </div>
            </el-form-item>
          </div>
          <div class="form-card">
            <div class="title">{{ $t(`systemManagement.searchpz`) }}</div>
            <el-form-item :label="$t(`systemManagement.searchpz`)" style="">
              <el-switch
                v-model="ruleForm.isOpen"
                :active-value="1"
                :inactive-value="0"
                active-color="#00ce6d"
                inactive-color="#d4dbe8"
              >
              </el-switch>
              <div class="iframe-row-card" v-if="ruleForm.isOpen">
                <div style="margin: 22px 0 22px 0">
                  <!-- <div class="card-row-left">关键词上限</div> -->
                  <!-- <div class="card-row-right"> -->
                  <el-form-item
                    :label="$t(`systemManagement.gjcsx`)"
                    prop="limitNum"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.limitNum"
                      :placeholder="$t('searchConfig.qsrgjcsx')"
                      @keyup.native="
                        ruleForm.limitNum = oninput2(ruleForm.limitNum)
                      "
                    ></el-input>
                  </el-form-item>
                  <!-- </div> -->
                </div>
                <div style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="$t(`systemManagement.gjc`)"
                    prop="keyword"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.keyword"
                      type="textarea"
                      :placeholder="$t('searchConfig.qsrgjc')"
                    ></el-input>
                    <span style="color: #97a0b4"
                      >({{ $t("searchConfig.gjcbz") }})</span
                    >
                  </el-form-item>
                </div>
              </div>
            </el-form-item>
          </div>

          <div class="form-card">
            <div class="title">{{ $t(`systemManagement.kdpz`) }}</div>
            <el-form-item :label="$t(`systemManagement.wlgs`)" style="">
              <!-- <el-switch
                v-model="ruleForm.is_courier"
                :active-value="1"
                :inactive-value="0"
                active-color="#00ce6d"
                inactive-color="#d4dbe8"
              >
              </el-switch> -->
              <el-select
                v-model="ruleForm.is_courier"
                :placeholder="$t(`systemManagement.qxzwlgs`)"
                style="margin-bottom: 10px; width: 370px"
              >
                <el-option label="快递100" :value="1"> </el-option>
              </el-select>
              <div class="iframe-row-card">
                <div style="margin: 22px 0 22px 0">
                  <!-- <div class="card-row-left">
                    {{ $t("systemManagement.cxjk") }}
                  </div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.api_address"></el-input>
                  </div> -->
                  <el-form-item
                    :label="$t(`systemManagement.cxjk`)"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input v-model="ruleForm.api_address"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <!-- <div class="card-row-left">customer</div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.customer"></el-input>
                  </div> -->
                  <el-form-item label="customer" :label-width="language==='en'?'170px':'100px'">
                    <el-input v-model="ruleForm.customer"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <!-- <div class="card-row-left">
                    {{ $t("systemManagement.sqkey") }}
                  </div>
                  <div class="card-row-right">
                    <el-input v-model="ruleForm.authorization"></el-input>
                  </div> -->
                  <el-form-item
                    :label="$t(`systemManagement.sqkey`)"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input v-model="ruleForm.authorization"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <el-form-item label="secret" :label-width="language==='en'?'170px':'100px'" prop="express_secret" >
                    <el-input v-model="ruleForm.express_secret"></el-input>
                  </el-form-item>
                </div>

                <div style="margin: 0 0 22px 0">
                  <el-form-item label="tempId" :label-width="language==='en'?'170px':'100px'">
                    <el-input v-model="ruleForm.express_tempId"></el-input>
                  </el-form-item>
                </div>
              </div>
            </el-form-item>
          </div>

          <div class="form-card">
            <div class="title">{{ $t(`systemManagement.sypz`) }}</div>
            <el-form-item :label="$t('systemManagement.sypz')">
              <!-- <el-switch v-model="ruleForm.is_unipush" :active-value="1" :inactive-value="0" active-color="#00ce6d" inactive-color="#d4dbe8">
            </el-switch> -->

              <p style="color: #97a0b4">
                {{ $t("systemManagement.spfxs") }}
              </p>
              <div class="iframe-row-card">
                <div class="" style="margin: 22px 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.mc')"
                    prop="watermarkName"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.watermarkName"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                  <!-- <div class="card-row-left">名称</div>
                <div class="card-row-right">
                  <el-input v-model="ruleForm.watermarkName"></el-input>
                </div> -->
                </div>

                <div class="" style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.wz')"
                    prop="watermarkUrl"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.watermarkUrl"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                  <!-- <div class="card-row-left">网址</div>
                <div class="card-row-right">
                  <el-input v-model="ruleForm.watermarkUrl"></el-input>
                </div> -->
                </div>
              </div>
            </el-form-item>
          </div>

          <div class="form-card">
            <div class="title">{{ $t(`systemManagement.dypz`) }}</div>
            <el-form-item :label="$t('systemManagement.dypz')">
              <!-- <el-switch v-model="ruleForm.is_unipush" :active-value="1" :inactive-value="0" active-color="#00ce6d" inactive-color="#d4dbe8">
            </el-switch> -->

              <p style="color: #97a0b4">
                {{ $t("systemManagement.dypzts") }}
              </p>
              <div class="iframe-row-card">
                <div class="" style="margin: 22px 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.dymc')"
                    prop="printName"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.printName"
                      :placeholder="$t('systemManagement.dymcts')"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                </div>

                <div class="" style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.dywz')"
                    prop="printUrl"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.printUrl"
                      :placeholder="$t('systemManagement.dywzts')"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                </div>

                <div class="" style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.dydz')"
                    prop="sheng"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-select
                      :class="language==='en'?'select-input2':'select-input'"
                      v-model="ruleForm.sheng"
                      :placeholder="$t('aftersaleAddress.add.sheng')"
                    >
                      <el-option
                        v-for="(item, index) in shengList"
                        :key="index"
                        :label="item.g_CName"
                        :value="item.g_CName"
                      >
                        <div @click="getShi(item.groupID)">
                          {{ item.g_CName }}
                        </div>
                      </el-option>
                    </el-select>
                    <el-select
                    :class="language==='en'?'select-input2':'select-input'"
                      v-model="ruleForm.shi"
                      :placeholder="$t('aftersaleAddress.add.shi')"
                    >
                      <el-option
                        v-for="(item, index) in shiList"
                        :key="index"
                        :label="item.g_CName"
                        :value="item.g_CName"
                      >
                        <div @click="getXian(item.groupID)">
                          {{ item.g_CName }}
                        </div>
                      </el-option>
                    </el-select>
                    <el-select
                    :class="language==='en'?'select-input2':'select-input'"
                      v-model="ruleForm.xian"
                      :placeholder="$t('aftersaleAddress.add.xian')"
                    >
                      <el-option
                        v-for="(item, index) in xianList"
                        :key="index"
                        :label="item.g_CName"
                        :value="item.g_CName"
                      >
                        <div>{{ item.g_CName }}</div>
                      </el-option>
                    </el-select>
                  </el-form-item>
                </div>
                <div class="" style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="''"
                    prop="address"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.address"
                      :placeholder="$t('systemManagement.dydzts')"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                </div>

                <div class="" style="margin: 0 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.dydh')"
                    prop="phone"
                    :label-width="language==='en'?'170px':'100px'"
                  >
                    <el-input
                      v-model="ruleForm.phone"
                      :placeholder="$t('systemManagement.dydhts')"
                      maxlength="30"
                    ></el-input>
                  </el-form-item>
                </div>
              </div>
            </el-form-item>
          </div>
          <div class="form-card">
            <div class="title">{{ $t('systemManagement.fzpz') }}</div>
            <el-form-item :label="$t('systemManagement.wxfz')">
              <el-switch
                @change="accChange()"
                v-model="ruleForm.isAccounts"
                :active-value="1"
                :inactive-value="0"
                active-color="#00ce6d"
                inactive-color="#d4dbe8"
              >
              </el-switch>
              <div class="iframe-row-card" v-if="ruleForm.isAccounts">
                <div class="" style="margin: 22px 0 22px 0">
                  <el-form-item
                    :label="$t('systemManagement.fzzhsz')"
                    prop="accountsSet"
                    :label-width="language==='en'?'170px':'115px'"
                  >
                    <el-input
                      v-model="ruleForm.accountsSet"
                      :placeholder="$t('systemManagement.qsrdycfzzh')"
                    ></el-input>
                  </el-form-item>
                </div>
              </div>
            </el-form-item>
          </div>
          <div class="footerBox">
            <!-- <el-button plain class="footer-cancel fontColor" @click="$router.go(-1)">取消</el-button> -->
            <el-button
              type="primary"
              class="footer-save bgColor mgleft"
              @click="submitForm('ruleForm')"
              >{{ $t("DemoPage.tableFromPage.save") }}</el-button
            >
          </div>
        </div>
      </el-form>
    </div>
    <div style="min-height: 0.8vw"></div>
  </div>
</template>

<script>
import basicConfiguration from "@/webManage/js/mall/systemManagement/basicConfiguration";
export default basicConfiguration;
</script>

<style scoped lang="less">
@import "../../../webManage/css/mall/systemManagement/basicConfiguration.less";
</style>
