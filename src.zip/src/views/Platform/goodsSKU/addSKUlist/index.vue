<template>
  <div class="container">
    商品SKU列表添加
  </div>
</template>

<script>
export default {
    name: 'addSKUlist'
}
</script>

<style>

</style>