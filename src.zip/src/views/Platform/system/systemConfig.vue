<template>
  <div class="container">
    <el-form
      :model="formMain"
      :rules="formRules"
      ref="ruleForm"
      :label-width="language == 'en' ? 'auto' : '120px'"
      class="demo-ruleForm"
    >
      <el-form-item :label="$t('systemConfig.dly')" prop="logo" required>
        <l-upload
          :limit="1"
          :size="152"
          :heightSize="50"
          v-model="formMain.logo"
          :text="$t('systemConfig.jy152')"
        >
        </l-upload>
      </el-form-item>
      <!-- <el-form-item
        :label="$t('systemConfig.bqxx')"
        class="copyright"
        prop="copyright_information"
      >
        <el-input
          v-model="formMain.copyright_information"
          :placeholder="$t('systemConfig.qsrbqxx')"
        ></el-input>
      </el-form-item>
      <el-form-item
        :label="$t('systemConfig.baxx')"
        class="record"
        prop="record_information"
      >
        <el-input
          v-model="formMain.record_information"
          :placeholder="$t('systemConfig.qsrbaxx')"
        ></el-input>
      </el-form-item> -->

      <el-form-item class="link" :label="$t('systemConfig.dlyyq')">
        <div
          v-for="(item, index) in formMain.linkPage"
          :key="index"
          class="linkBox"
        >
          <el-input
            class="link-name"
            v-model="item.name"
            :placeholder="$t('systemConfig.qsrljmc')"
          ></el-input>
          <!-- <el-button type="info" plain disabled style="margin-left: 10px;">https://</el-button> -->
          <el-input
            class="link-local"
            v-model="item.url"
            :placeholder="$t('systemConfig.qsrljdz')"
          >
            <!-- <template slot="prepend">https://</template> -->
          </el-input>
          <div class="add-reduction">
            <i
              class="el-icon-remove-outline"
              @click="delUrl(index)"
              v-if="
                formMain.linkPage.length > 0 && formMain.linkPage.length != 1
              "
            ></i>
            <i
              class="el-icon-circle-plus-outline"
              @click="addUrl()"
              v-if="index + 1 === formMain.linkPage.length"
            ></i>
            <span class="prompt2" v-if="index == 0">{{
              $t("systemConfig.yypt")
            }}</span>
          </div>
        </div>
      </el-form-item>
      <el-form-item :label="$t('systemConfig.h5dz')" prop="h5Domain">
        <el-input
          v-model="formMain.h5Domain"
          :placeholder="$t('systemConfig.srh5')"
        ></el-input>
        <span class="prompt">{{ $t("systemConfig.qsrktwx") }}</span>
      </el-form-item>
      <el-form-item :label="$t('systemConfig.gmllj')" prop="domainPath">
        <el-input
          v-model="formMain.domainPath"
          :placeholder="$t('systemConfig.qsrgmllj')"
        ></el-input>
        <span class="prompt">{{ $t("systemConfig.ljmw") }}</span>
      </el-form-item>
      <el-form-item :label="$t('systemConfig.scidggsz')" required>
        <!-- 配置了显示输入框 -->
        <el-input
          v-if="
            formMain.store_id_prefix != null && formMain.store_id_prefix != ''
          "
          v-model="formMain.store_id_prefix"
          disabled
        ></el-input>
        <!-- 没有配置显示按钮 -->
        <el-button
          v-if="
            formMain.store_id_prefix == null || formMain.store_id_prefix == ''
          "
          class="gz_bt"
          @click="addId()"
          >{{ $t("systemConfig.tjgz") }}</el-button
        >
        <span
          class="prompt"
          v-if="
            formMain.store_id_prefix == null || formMain.store_id_prefix == ''
          "
          >{{ $t("systemConfig.text") }}</span
        >
      </el-form-item>
      <el-form-item
        :label="$t('systemConfig.mrtxsz')"
        required
        prop="adminDefaultPortrait"
      >
        <!-- adminDefaultPortrait -->
        <l-upload
          :limit="1"
          :text="`${$t('systemConfig.mrtxszts')}`"
          v-model="formMain.adminDefaultPortrait"
        >
        </l-upload>
      </el-form-item>
      <div class="form-footer">
        <el-form-item>
          <el-button class="bgColor" type="primary" @click="Save('ruleForm')">{{
            $t("DemoPage.tableFromPage.save")
          }}</el-button>
          <!-- <el-button class="bdColor" @click="$router.go(-1)" plain>{{ $t('DemoPage.tableFromPage.cancel') }}</el-button> -->
        </el-form-item>
      </div>
    </el-form>
    <div class="dialog-block">
      <!-- 弹框组件 -->
      <el-dialog
        :title="$t('systemConfig.tjgz')"
        :visible.sync="dialogVisible"
        :before-close="handleClose"
      >
        <el-form
          :model="ruleForm2"
          :rules="rules2"
          ref="ruleForm2"
          label-width="auto"
          class="demo-ruleForm"
        >
          <el-form-item
            :label="$t('systemConfig.qzmc')"
            prop="id"
            class="proportion"
          >
            <el-input
              v-model="ruleForm2.id"
              :placeholder="$t('systemConfig.text2')"
            ></el-input>
          </el-form-item>
          <div class="form-footer">
            <el-form-item>
              <el-button class="footer-cancel fontColor" @click="handleClose">{{
                $t("integralMall.goodsDelivery.ccel")
              }}</el-button>
              <el-button type="primary" @click="determine('ruleForm2')">{{
                $t("integralMall.goodsDelivery.okk")
              }}</el-button>
            </el-form-item>
          </div>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import main from "@/webManage/js/platform/system/systemConfig";
export default main;
</script>

<style scoped lang="less">
@import "../../../webManage/css/platform/logisticsCompanyManage/logisticsCompanySave.less";
/deep/.el-form-item {
  .prompt {
    margin-left: 14px;
    color: #97a0b4;
  }
}
</style>
