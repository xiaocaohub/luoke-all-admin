<template>
  <div class="container">
    <div class="Search">
      <div class="Search-condition">
        <div class="query-input">
          <el-input
            size="medium"
            v-model="inputInfo.imageName"
            @keyup.enter.native="demand"
            class="Search-input"
            :placeholder="$t('resources.qsrdpmc')"
          ></el-input>
          <div class="select-date">
            <el-date-picker
              v-model="inputInfo.range"
              type="datetimerange"
              :range-separator="$t('reportManagement.businessReport.zhi')"
              :start-placeholder="$t('reportManagement.businessReport.ksrq')"
              :end-placeholder="$t('reportManagement.businessReport.jsrq')"
              value-format="yyyy-MM-dd HH:mm:ss"
              :editable="false"
            ></el-date-picker>
          </div>
        </div>
        <div class="btn-list">
          <el-button class="fontColor" @click="reset">{{
            $t("DemoPage.tableExamplePage.reset")
          }}</el-button>
          <el-button
            class="bgColor"
            type="primary"
            @click="demand"
            v-enter="demand"
            >{{ $t("DemoPage.tableExamplePage.demand") }}
          </el-button>
        </div>
      </div>
    </div>

    <div class="jump-list">
      <span v-for="(item, index) in button_list" :key="index">
        <el-button
          :disabled="is_disabled"
          style="
            background-color: #fff;
            border-radius: 0.25rem;
            border-radius: 4px;
          "
          @click="Del"
          class="fontColor"
          icon="el-icon-delete"
          v-if="item.title == '批量删除'"
        >
          {{ $t("DemoPage.tableExamplePage.Batch_delete") }}</el-button
        >
      </span>
    </div>
    <myTable ref="myTableData" :total="total" :tableHead="tableHead" :tableData="tableData" :loadData="loadData" :selection_change="Chose">
        
    </myTable>
    <!-- <div class="merchants-list" ref="tableFather">
      <el-table
        :element-loading-text="$t('DemoPage.tableExamplePage.loading_text')"
        v-loading="loading"
        :data="tableData"
        ref="table"
        class="el-table"
        style="width: 100%"
        :height="tableHeight"
        @selection-change="Chose"
      >
        <template
          slot="empty"
          v-if="tableData.length == 0 && !loading"
        >
          <div class="empty">
            <img src="../../../assets/imgs/empty.png" alt="" />
            <p style="color: #414658">{{ $t("zdata.zwsj") }}</p>
          </div>
        </template>

        <el-table-column type="selection" width="55"> </el-table-column>
        <el-table-column :label="$t('resources.xh')">
          <template slot-scope="scope">
            {{ scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column prop="p_name" :label="$t('resources.tx')">
          <template slot-scope="scope">
            <img :src="scope.row.imgUrl" alt="" @error="handleErrorImg" />
          </template>
        </el-table-column>
        <el-table-column
          prop="image_name"
          :label="$t('resources.tpmc')"
          width="300"
        >
        </el-table-column>
        <el-table-column
          prop="imgUrl"
          :label="$t('resources.tplj')"
          min-width="328"
        >
          <template slot-scope="scope">
            <a :href="scope.row.imgUrl" target="blank">{{
              scope.row.imgUrl
            }}</a>
            
          </template>
        </el-table-column>
        <el-table-column
          prop="mchName"
          :label="$t('resources.ssdp')"
          width="200"
        >
        </el-table-column>
        <el-table-column :label="$t('resources.scsj')" width="200">
          <template slot-scope="scope">
            {{ scope.row.add_time | dateFormat }}
          </template>
        </el-table-column>
      </el-table>
      <div class="pageBox" ref="pageBox" v-if="page.showPagebox">
        <div class="pageLeftText">
          {{ $t("DemoPage.tableExamplePage.show") }}
        </div>
        <el-pagination
          layout="sizes, slot, prev, pager, next"
          :prev-text="$t('DemoPage.tableExamplePage.prev_text')"
          :next-text="$t('DemoPage.tableExamplePage.next_text')"
          @size-change="handleSizeChange"
          :page-sizes="pagesizes"
          :current-page="pagination.page"
          @current-change="handleCurrentChange"
          :total="total"
        >
          <div class="pageRightText">
            {{ $t("DemoPage.tableExamplePage.on_show") }}{{ currpage }}-{{
              current_num
            }}{{ $t("DemoPage.tableExamplePage.twig") }}{{ total
            }}{{ $t("DemoPage.tableExamplePage.twig_notes") }}
          </div>
        </el-pagination>
      </div>
    </div> -->


  </div>
</template>


<script>
import myTable from "@/components/lkt_table";
import { del, save, index, download } from "@/api/resources/imageManage";
import { exportss } from "@/api/export/index";
import { mixinstest } from "@/mixins/index";
import { getStorage } from "@/utils/storage";
import { getButton } from "@/api/layout/information";
import ErrorImg from "@/assets/images/default_picture.png";
import { vendor } from "navigator";
import { label } from "@/api/goods/goodsList";
import { data } from "jquery";
export default {
  name: "list",
  mixins: [mixinstest],
  //初始化数据
  data() {
    return {

      
      dialogVisible: false,
      inputInfo: {
        imageName: "",
        range: "",
      },
      imageName: null,
      data: null,
      choseList: [],
      dataForm: {},
      button_list: [],
      //需要下载的图片
      needImg: null,
      is_disabled: true,
      
      //列表参数
      tableData: [],
      loading: true,
      //列表表头
      tableHead:[],
      //分页参数
      // pagesizes: [10, 25, 50, 100],
      // pagination: {
      //   page: 1,
      //   pagesize: 10,
      // },
      // currpage: 1,
      // current_num: 10,
      // dictionaryNum: 1,
      // pageSize: 10,
      // showPagebox: true,
      // // table高度
      // tableHeight: null,
      // loading: false,
    };
  },
  components:{
    myTable
  },
  //组装模板
  created() {
    this.tableHead=[
      {
        type:'selection',
        width:'55',
      },
      {
        label:this.$t('resources.xh'),
        data:{
          serial:true,
        }
      },
      {
        prop:'',
        label:this.$t('resources.tx'),
        type:'',
        width:'',
        min_width:'',
        data:{
          img:'imgUrl',
        }
      },
      {
        prop:'image_name',
        label:this.$t('resources.tpmc'),
        width:'300',
      },
      {
        prop:'',
        label:this.$t('resources.tplj'),
        data:{
          link:'imgUrl',
        },
        width:'328',
      },
      {
        prop:'mchName',
        label:this.$t('resources.ssdp'),
        width:'200',
      },
      {
        prop:'add_time',
        label:this.$t('resources.scsj'),
        width:'200',
      },
    ]
    this.getButtons();
  },
  mounted() {
    this.$nextTick(function () {
      this.loadData();
      // this.getHeight();

    });
    // window.addEventListener("resize", this.getHeight(), false);

  },
  methods: {
    //选中项
    Chose(obj) {
      this.choseList = [];
      obj.forEach((item) => {
        this.choseList.push(item.id);
      });
      if (!this.choseList.length) {
        this.is_disabled = true;
      } else {
        this.is_disabled = false;
      }
    },
    // // 图片错误处理
    // handleErrorImg(e) {
    //   console.log("图片报错了", e.target.src);
    //   e.target.src = ErrorImg;
    // },
    // // 获取table高度
    // getHeight() {
    //   this.tableHeight =
    //     this.$refs.tableFather.clientHeight - this.$refs.pageBox.clientHeight;
    // },
    
    //获取按纽权限
    async getButtons() {
      let route = getStorage("route");
      route.forEach((item) => {
        if (item.path == "imageList") {
          return (this.menuId = item.id);
        }
      });
      let buttonList = await getButton({
        api: "saas.role.getButton",
        menuId: this.menuId,
      });
      this.button_list = buttonList.data.data;
    },
    async loadData() {
      await this.getList().then();
    },
    // 获取列表
    async getList() {
      const res = await index({
        api: "admin.resources.index",
        pageNo: this.$refs.myTableData.dictionaryNum,
        pageSize: this.$refs.myTableData.pageSize,
        imageName: this.inputInfo.imageName,
        startTime: this.inputInfo.range?.[0] ?? "",
        endTime: this.inputInfo.range?.[1] ?? "",
      });
      this.total = res.data.data.total
          
          
      
      this.tableData = res.data.data.list;
      if (res.data.data.total < 10) {
        this.current_num = this.total;
      }
      if (this.total < this.current_num) {
        this.current_num = this.total;
      }
    },

    // 重置
    reset() {
      this.inputInfo.imageName = null;
      this.inputInfo.range = null;
    },
    handleClose() {
      this.dialogVisible = false;
    },

    // 查询
    demand() {
      this.showPagebox = false;
      this.$refs.myTableData.loading = true;
      this.$refs.myTableData.showPagebox = false;
      this.$refs.myTableData.dictionaryNum = 1;

      this.loadData().then(() => {
        this.$refs.myTableData.showPagebox = true;
        this.$refs.myTableData.loading = false;
        if (this.tableData.length > 5) {
          this.showPagebox = true;
        }
      });
    },

    // //选择一页多少条
    // handleSizeChange(e) {
    //   this.page.loading = true;
    //   this.pageSize = e;
    //   this.loadData().then(() => {
    //     this.currpage = (this.dictionaryNum - 1) * this.pageSize + 1;
    //     this.current_num =
    //       this.page.tableData.length === this.pageSize
    //         ? this.dictionaryNum * this.pageSize
    //         : this.total;
    //     this.page.loading = false;
    //   });
    // },

    // //点击上一页，下一页
    // handleCurrentChange(e) {
    //   this.page.loading = true;
    //   this.dictionaryNum = e;
    //   this.currpage = (e - 1) * this.pageSize + 1;
    //   this.loadData().then(() => {
    //     this.current_num =
    //       this.page.tableData.length === this.pageSize
    //         ? e * this.pageSize
    //         : this.total;
    //     this.page.loading = false;
    //   });
    // },
    //选中项
    Chose(obj) {
      this.choseList = [];
      obj.forEach((item) => {
        this.choseList.push(item.id);
      });
      if (!this.choseList.length) {
        this.is_disabled = true;
      } else {
        this.is_disabled = false;
      }
    },
    //批量下载
    async Download() {
      await exportss(
        {
          api: "admin.resources.downForZip",
          imgIds: this.choseList.toString(),
          exportType: 1,
        },
        "pagegoods"
      );
    },
    isFillList() {
      const totalPage = Math.ceil(
        (this.total - this.tableData.length) / this.pageSize
      ); // 总页数
      this.dictionaryNum =
        this.dictionaryNum > totalPage ? totalPage : this.dictionaryNum;
      this.dictionaryNum = this.dictionaryNum < 1 ? 1 : this.dictionaryNum;
      this.getList();
    },
    //批量删除
    Del() {
      this.$confirm(this.$t("zdata.qdysctpm"), this.$t("zdata.ts"), {
        confirmButtonText: this.$t("zdata.ok"),
        cancelButtonText: this.$t("zdata.off"),
        type: "warning",
      })
        .then(() => {
          del({
            api: "admin.resources.del",
            imgIds: this.choseList.toString(),
          }).then((res) => {
            if (res.data.code == "200") {
              this.$message({
                type: "success",
                message: this.$t("zdata.sccg"),
              });
              this.isFillList();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: this.$t("zdata.yqxsc"),
          });
        });
    },
  },
};
</script>


<style scoped lang="less">
a {
  color: #414658;
}
a:hover {
  color: #2d8cf0;
}
@import "../../../common/commonStyle/form";
@import "../../../webManage/css/resources/imageList.less";
</style>

