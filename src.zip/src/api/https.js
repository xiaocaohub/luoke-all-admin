import axios from 'axios'
import ElementUI from 'element-ui';
import { removeStorage, getStorage } from '@/utils/storage'
import router from '@/router'
import Config from "@/packages/apis/Config";
const request = axios.create({
  // timeout: 10000
})

// //loading对象
// let loading;
// //当前正在请求的数量
// let needLoadingRequestCount = 0;
// //显示loading
// function showLoading(target) {
//   // 后面这个判断很重要，因为关闭时加了抖动，此时loading对象可能还存在，
//   // 但needLoadingRequestCount已经变成0.避免这种情况下会重新创建个loading
//   if (needLoadingRequestCount === 0 && !loading) {
//     loading = ElementUI.Loading.service({
//       lock: true,
//       text: "Loading...",
//       background: 'rgba(255, 255, 255, 0.5)',
//       target: target || "body"
//     });
//   }
//   needLoadingRequestCount++;
// }
  
// //隐藏loading
// function hideLoading() {
//   needLoadingRequestCount--;
//   needLoadingRequestCount = Math.max(needLoadingRequestCount, 0); //做个保护
//   if (needLoadingRequestCount === 0) {
//     //关闭loading
//     toHideLoading();
//   }
// }
// //防抖：将 300ms 间隔内的关闭 loading 便合并为一次。防止连续请求时， loading闪烁的问题。
// var toHideLoading = _.debounce(()=>{
//   loading.close();
//   loading = null;
// }, 300);

function getCookie(name) {
  var cookies = document.cookie;
  var list = cookies.split("; ");     // 解析出名/值对列表
       
  for(var i = 0; i < list.length; i++) {
    var arr = list[i].split("=");   // 解析出名和值
    if(arr[0] == name)
    return decodeURIComponent(arr[1]);   // 对cookie值解码
  } 
  return "";
 }

request.defaults.baseURL = Config.baseUrl

// 配置请求拦截器
request.interceptors.request.use(config => {
  // if(config.headers.showLoading !== false){
  //   showLoading(config.headers.loadingTarget);
  // }
  if (config.method === 'post') {
    const userInfo = getStorage('laike_admin_uaerInfo')
    config.params = {
      //商城id
      storeId: userInfo.storeId,
      //来源
      storeType: 8,
      ...config.params,
      //token
      accessId: userInfo.token,
      language:getCookie('language')
    }

    if(config.params.exportType && config.params.exportType == 1){
      config.headers = {
        'Content-Type': 'application/octet-stream;charset=utf-8'
      }
      config.responseType="blob";
    }
  }
  return config
}, err => {
  // if(config.headers.showLoading !== false){
  //   hideLoading();
  // }
  return Promise.reject(err)
})

// 配置响应拦截器
request.interceptors.response.use((res) => {
  // if(res.config.headers.showLoading !== false){
  //   hideLoading();
  // }
  if(res.data.code == '203') {
    let type = getStorage('rolesInfo').type
    // if(type == 0) {
    //   window.localStorage.clear()
    //   window.location.href = '/login'
    //   location.reload();
    // } else {
    //   window.localStorage.clear()
    //   window.location.href = '/mallLogin'
    //   location.reload();
    // }
    if(type == 0) {
      window.localStorage.clear()
      router.push({
        path: '/login'
      })
    } else {
      window.localStorage.clear()
      router.push({
        path: '/mallLogin'
      })
    }
  }
  if(res.data instanceof Blob){
    return res
  }
  if (res.status && res.data.code == '200') {
    return res;
  } else {
    ElementUI.Message.closeAll()
    ElementUI.Message({
      message: res.data.message,
      type: 'error',
      offset: 100
    })
    return res
  }

  console.log(res);

}, (error) => {
  // if(error.config.headers.showLoading !== false){
  //   hideLoading();
  // }

});

export default request;
