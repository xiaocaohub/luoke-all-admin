import { setStorage, getStorage } from '@/utils/storage'
import store from '@/store/index'
import { isEmpty } from 'element-ui/src/utils/util'
import { MessageBox, Message } from 'element-ui'
import { router } from '@/router'

const data = {
  install (Vue) {
    Vue.prototype.fn1 = function (value) {
      console.log(value)
    }

    Vue.prototype.fn2 = function () {
      console.log(456)
    }

    //获取来源
    Vue.prototype.getSource = function () {
      let obj = getStorage('laike_source')
      if (isEmpty(obj)) {
        store
          .dispatch('source/getSource')
          .then(r => (obj = getStorage('laike_source')))
      }
      let map = new Map()
      for (let i = 0, l = obj.length; i < l; i++) {
        let source = obj[i]
        map.set(source.value, source.label)
      }
      return map
    }

    // 设置只能输入整数
    Vue.prototype.oninput2 = function (num) {
      var str = num
      str = str.replace(/[^\.\d]/g, '')
      str = str.replace('.', '')

      return str
    }

    // 设置只能输入整数和小数
    Vue.prototype.oninput = function (num, limit) {
      var str = num
      var len1 = str.substr(0, 1)
      var len2 = str.substr(1, 1)
      //如果第一位是0，第二位不是点，就用数字把点替换掉
      if (str.length > 1 && len1 == 0 && len2 != '.') {
        str = str.substr(1, 1)
      }
      //第一位不能是.
      if (len1 == '.') {
        str = ''
      }
      //限制只能输入一个小数点
      if (str.indexOf('.') != -1) {
        var str_ = str.substr(str.indexOf('.') + 1)
        if (str_.indexOf('.') != -1) {
          str = str.substr(0, str.indexOf('.') + str_.indexOf('.') + 1)
        }
      }
      //正则替换
      str = str.replace(/[^\d^\.]+/g, '') // 保留数字和小数点
      if (limit / 1 === 1) {
        str = str.replace(/^\D*([0-9]\d*\.?\d{0,1})?.*$/, '$1') // 小数点后只能输 1 位
      } else {
        str = str.replace(/^\D*([0-9]\d*\.?\d{0,2})?.*$/, '$1') // 小数点后只能输 2 位
      }

      return str
    }

    // 设置不能输入特殊字符
    Vue.prototype.oninput3 = function (num) {
      var str = num
      str = str.replace(/[^\w]/g, '')

      return str
    }

    // 设置不能输入汉字
    Vue.prototype.oninput4 = function (num) {
      var str = num
      str = str.replace(/[\u4E00-\u9FA5]/g, '')

      return str
    }

    Vue.prototype.stripscript = function (value) {
      var pattern = new RegExp(
        "[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]"
      )
      var rs = ''
      for (var i = 0; i < value.length; i++) {
        rs = rs + value.substr(i, 1).replace(pattern, '')
      }
      return rs
    }

    //判断数组中是否包含某个值（检测按钮权限用）
    Vue.prototype.detectionBtn = function (arr, value) {
      return arr.some(item => item === value)
    }

    // 判断tab路由是否存在该权限设置
    let mySong = (route, value, name) => {
      if (name === 1) {
        return route.some(item => item.module === value)
      } else {
        return route.some(item => item.url === value)
      }
    }
    Vue.prototype.handleTabLimits = function (route, value, name) {
      // console.log('路由权限列表xxxxxx',route);
      return mySong(route, value, name)
      return true
    }

    /**
      * xuxiong
      * 如何调用，如下面调用案例,页面直接this调用
      * this.succesMsg(this.$t("zdata.sccg"))
      * this.warnMsg(this.$t("zdata.sccg"))
      * ....
      * this.confirmBox('确认删除该标签吗？',...其他参数).then(res => {
          确认后的逻辑执行
        }).catch(res => {
          取消回调
        })
    **/
    // 成功提示信息
    Vue.prototype.succesMsg = function (msg) {
      Message({
        type: 'success',
        // showClose: true,
        dangerouslyUseHTMLString: true,
        message: msg,
        offset: 102
      })
    }
    // 警告提示信息
    Vue.prototype.warnMsg = function (msg) {
      Message({
        type: 'warning',
        // showClose: true,
        dangerouslyUseHTMLString: true,
        message: msg,
        offset: 102
      })
    }
    // 错误提示信息
    Vue.prototype.errorMsg = function (msg) {
      Message({
        type: 'error',
        // showClose: true,
        dangerouslyUseHTMLString: true,
        message: msg,
        offset: 102
      })
    }
    // 一般信息提示信息
    Vue.prototype.infoMsg = function (msg) {
      Message({
        type: 'info',
        // showClose: true,
        dangerouslyUseHTMLString: true,
        message: msg,
        offset: 102
      })
    }
    // 确定一个确定按钮alertBox
    Vue.prototype.alertBox = function (msg, type, title, btnName) {
      // title是提示标题，没有传递就是默认为提示,是非必传参数
      // msg参数是提示的内容，必传参数
      // type是传递消息提示是什么类型，也是非必传参数，默认为warning
      // btnName是修改确认按钮文字 非必传
      let titleName = title ?? this.$t('zdata.ts')
      let confirmName = btnName ?? this.$t('zdata.zdl')
      let typeName = type ?? 'warning'
      return MessageBox.alert(msg, titleName, {
        type: typeName,
        confirmButtonText: confirmName,
        dangerouslyUseHTMLString: true
      })
    }
    // 确定取消;是否按钮弹出框
    Vue.prototype.confirmBox = function (msg, type, title, btnName) {
      // title是提示标题，没有传递就是默认为提示,是非必传参数
      // msg参数是提示的内容，必传参数
      // type是传递消息提示是什么类型，也是非必传参数，默认为warning
      // btnName是修改确认按钮文字 非必传
      let titleName = title ?? this.$t('zdata.ts')
      let typeName = type ?? 'warning'
      let confirmName = btnName ?? this.$t('zdata.ok')
      let cancelsName =
        btnName == this.$t('zdata.ok') ? this.$t('zdata.off') : ''
      return MessageBox.confirm(msg, titleName, {
        type: typeName,
        confirmButtonText: confirmName, //确认按钮文字
        cancelButtonText: cancelsName, //取消按钮文字
        closeOnClickModal: false, //是否可通过点击遮罩层关闭 MessageBox
        closeOnPressEscape: false, //是否可通过按下 ESC 键关闭 MessageBox
        dangerouslyUseHTMLString: true //是否将 message 作为 HTML 片段处理
      })
    }
  }
}

export default data
