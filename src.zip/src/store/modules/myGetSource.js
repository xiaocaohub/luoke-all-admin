export function myGetSource (value) {
	if (value == "1") {
        return this.$t('orderStates')[1];
    } else if (value == "2") {
        return this.$t('orderStates')[2];
    } else if (value == "3") {
        return this.$t('orderStates')[3];
    } else if (value == "4") {
        return this.$t('orderStates')[4];
    } else if (value == "5") {
        return this.$t('orderStates')[5];
    } else if (value == "6") {
        return this.$t('orderStates')[6];
    } else if (value == "7") {
        return this.$t('orderStates')[7];
    } else if (value == "8") {
        return this.$t('orderStates')[8];
    } else if (value == "9") {
        return this.$t('orderStates')[9];
    } else if (value == "10") {
        return this.$t('orderStates')[10];
    } else if (value == "11") {
        return this.$t('orderStates')[11];
    } else if (value == "12") {
        return this.$t('orderStates')[12];
    } else {
        return this.$t('orderStates')[13];
    }
}
